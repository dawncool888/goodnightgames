import React, { useState } from 'react';
import Card from './common/Card';
import { Settings } from '../types';
import { useTranslations } from '../constants';
import { PaperPlaneIcon } from './icons/ThemeIcons';

interface WishSenderModalProps {
    onClose: () => void;
    onSend: (wishText: string) => void;
    isAnimatingOut: boolean;
    settings: Settings;
}

const WishSenderModal: React.FC<WishSenderModalProps> = ({ onClose, onSend, isAnimatingOut, settings }) => {
    const t = useTranslations(settings.language);
    const [wishText, setWishText] = useState('');
    const [isAnimating, setIsAnimating] = useState(false);

    const handleSend = () => {
        if (wishText.trim() === '' || isAnimating) return;
        setIsAnimating(true);
        setTimeout(() => {
            onSend(wishText);
            // The modal will be closed by the parent component after onSend completes
        }, 2000); // Corresponds to fly-off animation
    };

    return (
        <div 
            className={`fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 ${isAnimatingOut ? 'animate-fade-out' : 'animate-fade-in'}`}
            onClick={onClose}
        >
            <Card className="w-full max-w-sm p-6 relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
                {isAnimating && (
                    <div 
                        className="absolute inset-0 flex items-center justify-center animate-fly-off z-20"
                        style={{ top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }}
                    >
                        <div className="w-16 h-16 bg-jelly-pink/50 rounded-full flex items-center justify-center shadow-[0_0_20px_10px_var(--jelly-pink)]">
                            <PaperPlaneIcon className="w-8 h-8 text-white" />
                        </div>
                    </div>
                )}
                <div className={`${isAnimating ? 'opacity-0' : 'opacity-100'} transition-opacity duration-300`}>
                    <h3 className="font-bold text-lg mb-4 text-center text-jelly-pink">{t('sendAWish')}</h3>
                    <textarea
                        value={wishText}
                        onChange={(e) => setWishText(e.target.value)}
                        maxLength={80}
                        placeholder={t('writeYourWish')}
                        className="w-full h-20 bg-white/5 border border-white/20 rounded-lg p-2 text-sm text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-jelly-pink resize-none"
                    />
                    <button
                        onClick={handleSend}
                        disabled={wishText.trim() === ''}
                        className="mt-4 w-full px-4 py-2 bg-jelly-pink/80 hover:bg-jelly-pink rounded-full backdrop-blur-sm transition-all duration-300 text-base font-semibold shadow-lg active:scale-95 disabled:bg-gray-500/50 disabled:cursor-not-allowed"
                    >
                        {t('sendToStars')}
                    </button>
                </div>
            </Card>
        </div>
    );
};

export default WishSenderModal;