import { useLocalStorage } from './useLocalStorage';
import type { User } from '../types';
import { handleLoginRequest } from '../services/authService';

const GUEST_USER: User = {
    id: 'guest',
    name: 'Guest',
    isGuest: true,
};

// This is the hook that will be used by the App
export function useAuth(onFirstLogin?: () => void): { user: User, login: () => void } {
    const [user, setUser] = useLocalStorage<User>('user', GUEST_USER);

    // This function will be called by the UI to initiate the login process
    const login = async () => {
        // This calls the stub function which you will replace with your native SDK call.
        const platformUserData = await handleLoginRequest();

        if (platformUserData) {
            // Logic from onLoginSuccess is now here.
            const wasGuest = user.isGuest;
            const newUser: User = {
                id: platformUserData.id,
                name: platformUserData.name,
                isGuest: false,
                avatar: platformUserData.avatar,
            };
            setUser(newUser);

            if (wasGuest && onFirstLogin) {
                onFirstLogin();
            }
        }
    };
    
    return { user, login };
}