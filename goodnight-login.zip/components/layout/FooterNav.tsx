import React from 'react';
import { HomeIcon, CollectionIcon, ReportIcon, ShopIcon, PlanetIcon } from '../icons/ThemeIcons';
import { Screen, Settings } from '../../types';
import { useTranslations } from '../../constants';

interface FooterNavProps {
    activeScreen: Screen;
    navigateTo: (screen: Screen) => void;
    settings: Settings;
}

const NavItem: React.FC<{
    icon: React.FC<{ className?: string }>;
    label: string;
    isActive: boolean;
    onClick: () => void;
}> = ({ icon: Icon, label, isActive, onClick }) => {
    const activeClasses = 'text-jelly-pink scale-110';
    const inactiveClasses = 'text-white/60 hover:text-white';
    
    return (
        <button 
            onClick={onClick} 
            className={`flex flex-col items-center gap-1 transition-all duration-200 ${isActive ? activeClasses : inactiveClasses}`}
        >
            <Icon className="w-7 h-7" />
            <span className="text-xs font-semibold">{label}</span>
        </button>
    )
};

const FooterNav: React.FC<FooterNavProps> = ({ activeScreen, navigateTo, settings }) => {
    const t = useTranslations(settings.language);
    
    const navItems = [
        { screen: 'themeSelector', icon: HomeIcon, label: t('home') },
        { screen: 'collection', icon: CollectionIcon, label: t('collection') },
        { screen: 'asteroid', icon: PlanetIcon, label: t('asteroid') },
        { screen: 'shop', icon: ShopIcon, label: t('shop') },
        { screen: 'report', icon: ReportIcon, label: t('report') },
    ] as const;

    return (
        <footer 
            className="absolute bottom-0 left-0 right-0 z-30 p-2"
            style={{ paddingBottom: `calc(0.5rem + env(safe-area-inset-bottom))` }}
        >
            <div className="max-w-md mx-auto bg-black/20 backdrop-blur-lg border border-white/10 rounded-full flex justify-around items-center p-3">
                {navItems.map(item => (
                    <NavItem 
                        key={item.screen}
                        icon={item.icon}
                        label={item.label}
                        isActive={activeScreen === item.screen}
                        onClick={() => navigateTo(item.screen)}
                    />
                ))}
            </div>
        </footer>
    );
};

export default FooterNav;