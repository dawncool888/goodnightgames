import React, { useState } from 'react';
import { useTranslations, SHOP_ITEMS } from '../constants';
import Card from './common/Card';
import type { GameTheme, Screen, Settings, TranslationKey, ShopItem } from '../types';
import { CoinIcon, LockedIcon, PaperPlaneIcon } from './icons/ThemeIcons';

interface ThemeSelectorProps {
  onThemeSelect: (theme: GameTheme) => void;
  onOpenWishSender: () => void;
  settings: Settings;
  jellysWishTheme: GameTheme;
  unlockedThemes: GameTheme[];
  navigateTo: (screen: Screen) => void;
  wishCoins: number;
  onPurchase: (item: ShopItem) => boolean;
  onCoinsAdClick: () => void;
}

const ThemeSelector: React.FC<ThemeSelectorProps> = ({ 
  onThemeSelect, 
  onOpenWishSender, 
  settings, 
  jellysWishTheme, 
  unlockedThemes, 
  navigateTo,
  wishCoins,
  onPurchase,
  onCoinsAdClick
}) => {
  const t = useTranslations(settings.language);
  const [purchaseFocusId, setPurchaseFocusId] = useState<string | null>(null);
  
  const allGames = SHOP_ITEMS.filter(item => item.category === 'game') as GameTheme[];

  const handleCardClick = (theme: GameTheme, isUnlocked: boolean) => {
    if (isUnlocked) {
      onThemeSelect(theme);
    } else {
      setPurchaseFocusId(prevId => prevId === theme.id ? null : theme.id);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center text-center">
      <h2 className="text-xl text-white/80 mb-6">{t('chooseGame')}</h2>

      <div className="mb-6 w-full max-w-xs flex flex-col gap-3">
           <button 
                onClick={onOpenWishSender}
                className="w-full text-center p-3 rounded-2xl bg-jelly-pink/20 border border-jelly-pink/50 hover:bg-jelly-pink/30 transition-all duration-300 flex items-center justify-center gap-2"
            >
                <PaperPlaneIcon className="w-5 h-5 text-jelly-pink"/>
                <span className="font-semibold text-jelly-pink">{t('sendAWishHome')}</span>
            </button>
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-6 pt-4">
        {allGames.map((theme) => {
          const isUnlocked = unlockedThemes.some(unlocked => unlocked.id === theme.id);
          const isJellysWish = theme.id === jellysWishTheme.id;
          const isPurchaseFocused = purchaseFocusId === theme.id;

          if (isUnlocked) {
            return (
              <Card
                key={theme.id}
                className={`relative flex flex-col items-center justify-center p-4 aspect-square ${theme.bgColor} ${isJellysWish ? 'animate-wobble shadow-lg shadow-pink-500/40' : ''}`}
                onClick={() => handleCardClick(theme, true)}
              >
                {isJellysWish && (
                   <div className="absolute -top-3 bg-jelly-pink text-white text-xs font-bold px-3 py-1 rounded-full shadow-md z-10">
                        {t('jellysWishToday')}
                    </div>
                )}
                <theme.icon className={`${theme.color} w-12 h-12 md:w-16 md:h-16 mb-2`} />
                <span className={`font-semibold ${theme.color}`}>{t(theme.id as TranslationKey)}</span>
              </Card>
            );
          } else {
            return (
               <Card
                key={`locked-${theme.id}`}
                className={`flex flex-col items-center justify-center p-4 aspect-square bg-black/30 cursor-pointer transition-all duration-300 ${isPurchaseFocused ? 'bg-black/50 scale-105' : 'hover:bg-black/40'}`}
                onClick={() => handleCardClick(theme, false)}
              >
                {isPurchaseFocused ? (
                     <div className="flex flex-col items-center justify-around h-full w-full animate-fade-in" onClick={e => e.stopPropagation()}>
                        <div className="flex items-center gap-2">
                            <CoinIcon className="w-6 h-6 text-yellow-300" />
                            <span className="text-xl font-bold text-white">{theme.cost}</span>
                        </div>
                        {wishCoins >= theme.cost ? (
                            <button 
                                onClick={() => {
                                    if(onPurchase(theme)) {
                                        setPurchaseFocusId(null);
                                    }
                                }}
                                className="w-full px-3 py-2 text-sm bg-jelly-pink hover:bg-opacity-80 rounded-full text-white font-semibold transition-transform active:scale-95"
                            >
                                {t('purchase')}
                            </button>
                        ) : (
                            <button
                                onClick={onCoinsAdClick}
                                className="w-full px-3 py-2 text-sm bg-jelly-purple hover:bg-opacity-80 rounded-full text-white font-semibold transition-transform active:scale-95"
                            >
                                {t('getWishCoins')}
                            </button>
                        )}
                    </div>
                ) : (
                    <>
                        <div className="relative flex items-center justify-center w-12 h-12 md:w-16 md:h-16 mb-2">
                        <theme.icon className={`w-full h-full ${theme.color} opacity-30`} />
                        <LockedIcon className="absolute w-8 h-8 text-white/50" />
                        </div>
                        <span className={`font-semibold text-white/40`}>{t(theme.id as TranslationKey)}</span>
                    </>
                )}
              </Card>
            );
          }
        })}
      </div>
    </div>
  );
};

export default ThemeSelector;