// services/adService.ts

/**
 * 广告奖励类型定义
 * success: 广告是否成功播放完毕
 * reward: 如果成功，返回的奖励内容
 */
export type AdResult = {
    success: boolean;
    reward?: AdReward;
};

export type AdReward = 
    | { type: 'plays', amount: number } 
    | { type: 'wishes', amount: number } 
    | { type: 'coins', amount: number };

/**
 * 定义广告位ID的类型，确保类型安全
 */
export type AdPlacement = 'extra_plays' | 'extra_wishes' | 'coin_reward';


/**
 * 检查指定类型的广告位是否还可以展示广告。
 * 
 * [待办] 您需要在此处实现具体的逻辑。
 * 1. 这个函数已经被App.tsx中的状态管理所替代，但为您保留结构以备未来对接后端。
 * 
 * @param placementId 广告位ID ('extra_plays', 'extra_wishes', 'coin_reward')
 * @returns Promise<boolean> - 返回一个Promise，解析为布尔值，表示是否可以展示广告。
 */
export async function canShowAd(placementId: AdPlacement): Promise<boolean> {
    console.log(`检查广告位 '${placementId}' 是否可展示...`);
    // 当前为模拟逻辑，默认总是可以展示
    return Promise.resolve(true);
}

/**
 * 根据广告位ID，向用户展示一个激励视频广告。
 * 
 * [待办] 您需要在此处实现与您选择的广告SDK的对接逻辑。
 * 
 * @param placementId 广告位ID
 * @returns Promise<AdResult> - 返回一个Promise，解析为一个包含播放结果和奖励信息的对象。
 */
export async function showRewardedAd(placementId: AdPlacement): Promise<AdResult> {
    console.log(`尝试展示广告，位置: '${placementId}'...`);
    
    // --- 这是模拟逻辑，它会直接跳过广告并总是返回成功 ---
    return new Promise((resolve) => {
        // 模拟一个极短的延迟，让UI反馈更自然
        setTimeout(() => {
            console.log("广告播放成功! (模拟)");
            let reward: AdReward | undefined;

            switch (placementId) {
                case 'extra_plays':
                    reward = { type: 'plays', amount: 3 };
                    break;
                case 'extra_wishes':
                    // 每次广告只奖励1次许愿机会
                    reward = { type: 'wishes', amount: 1 };
                    break;
                case 'coin_reward':
                    // 随机奖励10到50个币
                    const amount = Math.floor(Math.random() * 41) + 10;
                    reward = { type: 'coins', amount: amount };
                    break;
            }
            resolve({ success: true, reward });
            
        }, 500); // 模拟0.5秒的“广告”时间
    });
    // --- 模拟逻辑结束 ---
}