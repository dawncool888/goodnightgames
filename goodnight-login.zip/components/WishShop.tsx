import React, { useState } from 'react';
import Card from './common/Card';
import { SHOP_ITEMS, useTranslations } from '../constants';
import type { Settings, ShopItem, ShopCategory, TranslationKey } from '../types';
import { CoinIcon, PaperPlaneIcon } from './icons/ThemeIcons';

interface WishShopProps {
    settings: Settings;
    setSettings: React.Dispatch<React.SetStateAction<Settings>>;
    wishCoins: number;
    setWishCoins: React.Dispatch<React.SetStateAction<number>>; 
    unlockedItems: string[];
    onPurchase: (item: ShopItem) => boolean;
    onCoinsAdClick: () => void;
}

const WishShop: React.FC<WishShopProps> = ({ settings, setSettings, wishCoins, unlockedItems, onPurchase, onCoinsAdClick }) => {
    const t = useTranslations(settings.language);
    const [activeTab, setActiveTab] = useState<ShopCategory>('game');

    const handlePurchaseClick = (item: ShopItem) => {
        if (onPurchase(item)) {
            // Success! The parent component handles the state update.
        } else {
            alert(t('insufficientCoins'));
        }
    };

    const handleEquipSkin = (item: ShopItem) => {
        // Type guard to ensure item is a skin
        if (item.category !== 'skin' || !item.gameId) return;
        setSettings(s => ({
            ...s,
            activeSkins: {
                ...s.activeSkins,
                [item.gameId!]: item.id,
            }
        }));
    };

    const handleApplyTheme = (item: ShopItem) => {
        setSettings(s => ({ ...s, activeTheme: item.id }));
    };

    const tabs: { key: ShopCategory, label: string }[] = [
        { key: 'game', label: t('shopGames') },
        { key: 'skin', label: t('shopSkins') },
        { key: 'theme', label: t('shopThemes') },
        { key: 'decoration', label: t('shopDecorations') },
    ];
    
    const itemsForTab = SHOP_ITEMS.filter(item => item.category === activeTab && item.cost >= 0);

    return (
        <div className="flex flex-col items-center w-full h-full max-w-md mx-auto">
            <div className="w-full flex justify-center my-4 flex-shrink-0">
                <div className="flex bg-black/20 p-1 rounded-full">
                    {tabs.map(tab => (
                        <button
                            key={tab.key}
                            onClick={() => setActiveTab(tab.key)}
                            className={`px-3 py-1.5 text-xs sm:px-4 sm:py-2 sm:text-sm rounded-full transition-colors duration-300 ${activeTab === tab.key ? 'bg-jelly-pink' : 'text-white/70'}`}
                        >
                            {tab.label}
                        </button>
                    ))}
                </div>
            </div>

            <div className="w-full flex-grow overflow-y-auto grid grid-cols-2 gap-4 pr-1 pb-4 no-scrollbar">
                {itemsForTab.length > 0 ? itemsForTab.map(item => {
                    const isUnlocked = unlockedItems.includes(item.id);
                    let isEquipped = false;
                    if (item.category === 'skin' && item.gameId) {
                        isEquipped = settings.activeSkins[item.gameId] === item.id;
                    } else if (item.category === 'theme') {
                        isEquipped = settings.activeTheme === item.id;
                    }

                    return (
                        <Card key={item.id} className="p-3 flex flex-col items-center gap-2 text-center justify-between">
                             <div className={`w-16 h-12 rounded-lg flex items-center justify-center ${item.bgColor}`}>
                                <item.icon className={`w-9 h-9 ${item.color}`} />
                            </div>
                            <div className="flex-grow flex flex-col justify-center">
                                <h3 className="font-bold text-sm leading-tight mt-1">{t(item.id as TranslationKey)}</h3>
                                <p className="text-xs text-white/70 mt-1 leading-tight line-clamp-2">{t(`desc-${item.id}` as TranslationKey)}</p>
                            </div>
                            <div className="flex flex-col items-center w-full mt-2">
                                {isUnlocked ? (
                                    (item.category === 'game' || item.category === 'decoration') ? (
                                        <button disabled className="w-full px-3 py-1.5 bg-green-600/50 rounded-full text-xs font-semibold cursor-default">
                                            {t('owned')}
                                        </button>
                                    ) : isEquipped ? (
                                        <button disabled className="w-full px-3 py-1.5 bg-green-600/50 rounded-full text-xs font-semibold cursor-default">
                                            {item.category === 'theme' ? t('applied') : t('equipped')}
                                        </button>
                                    ) : (
                                        <button 
                                            onClick={() => item.category === 'skin' ? handleEquipSkin(item) : handleApplyTheme(item)}
                                            className="w-full px-3 py-1.5 bg-jelly-pink/80 hover:bg-jelly-pink rounded-full transition-all duration-300 text-xs font-semibold shadow active:scale-95"
                                        >
                                            {item.category === 'theme' ? t('apply') : t('equip')}
                                        </button>
                                    )
                                ) : (
                                    <button
                                        onClick={() => handlePurchaseClick(item)}
                                        disabled={wishCoins < item.cost}
                                        className="w-full px-3 py-1.5 bg-orange-500/90 hover:bg-orange-600 rounded-full transition-all duration-300 text-xs font-semibold shadow active:scale-95 disabled:bg-gray-500/50 disabled:cursor-not-allowed"
                                    >
                                        <div className="flex items-center justify-center gap-1">
                                            <CoinIcon className="w-3 h-3" />
                                            <span>{item.cost}</span>
                                        </div>
                                    </button>
                                )}
                            </div>
                        </Card>
                    );
                }) : (
                     <p className="col-span-2 text-center text-white/60 pt-10">{t('comingSoon')}</p>
                )}
            </div>
            <div className="w-full flex-shrink-0 mt-2">
                <button 
                    onClick={onCoinsAdClick}
                    className="w-full text-center p-2.5 rounded-full bg-jelly-purple/20 border border-jelly-purple/50 hover:bg-jelly-purple/30 transition-all duration-300 flex items-center justify-center gap-2"
                >
                    <PaperPlaneIcon className="w-4 h-4 text-jelly-purple"/>
                    <span className="font-semibold text-jelly-purple text-sm">{t('watchAdForCoins')}</span>
                </button>
            </div>
        </div>
    );
};

export default WishShop;