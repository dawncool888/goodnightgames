import React from 'react';
import { LogoIcon, SheepSettingsIcon, CoinIcon, UserIcon } from '../icons/ThemeIcons';
import { User } from '../../types';

interface HeaderProps {
    onLogoClick: () => void;
    onSettingsClick: () => void;
    onCoinsClick: () => void;
    wishCoins: number;
    user: User;
    onLoginClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onLogoClick, onSettingsClick, onCoinsClick, wishCoins, user, onLoginClick }) => {
    return (
        <header 
            className="absolute top-0 left-0 right-0 z-30 px-4 pb-4 flex justify-between items-center bg-gradient-to-b from-night-sky-start/50 to-transparent"
            style={{ paddingTop: `calc(1rem + 30px + env(safe-area-inset-top))` }}
        >
            <button onClick={onLogoClick} className="p-2 transition-transform duration-200 ease-in-out hover:scale-110 active:scale-95" aria-label="Home">
                <LogoIcon />
            </button>
            <div className="flex items-center gap-2 sm:gap-4">
                 <button 
                    onClick={onCoinsClick}
                    className="flex items-center gap-2 bg-black/20 backdrop-blur-md border border-white/10 rounded-full px-3 py-1 transition-all duration-200 hover:bg-black/30 hover:border-white/20"
                    aria-label="Get more Wish Coins"
                >
                    <CoinIcon className="w-5 h-5 text-yellow-400"/>
                    <span className="font-bold text-yellow-300">{wishCoins}</span>
                </button>

                {user.isGuest ? (
                    <button onClick={onLoginClick} className="p-2 transition-transform duration-200 ease-in-out hover:scale-110 active:scale-95" aria-label="Login">
                        <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
                            <UserIcon className="w-6 h-6 text-white/80" />
                        </div>
                    </button>
                ) : (
                    <button onClick={onLoginClick} className="p-2 transition-transform duration-200 ease-in-out hover:scale-110 active:scale-95" aria-label="User Profile">
                         {user.avatar ? (
                            <img src={user.avatar} alt="User Avatar" className="w-10 h-10 rounded-full border-2 border-white/50" />
                         ) : (
                            <div className="w-10 h-10 rounded-full bg-jelly-purple flex items-center justify-center">
                               <span className="font-bold text-lg">{user.name.charAt(0)}</span>
                            </div>
                         )}
                    </button>
                )}
               
                <button onClick={onSettingsClick} className="p-2 transition-transform duration-200 ease-in-out hover:scale-110 active:scale-95" aria-label="Settings">
                    <SheepSettingsIcon className="w-10 h-10"/>
                </button>
            </div>
        </header>
    );
};

export default Header;