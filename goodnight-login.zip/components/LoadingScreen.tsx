import React, { useState, useEffect, useMemo } from 'react';
import { LogoIcon } from './icons/ThemeIcons';
import { useTranslations } from '../constants';
import { Settings } from '../types';

interface LoadingScreenProps {
  isLoading: boolean;
  settings: Settings;
}

const LoadingScreen: React.FC<LoadingScreenProps> = ({ isLoading, settings }) => {
  const t = useTranslations(settings.language);
  const [visible, setVisible] = useState(true);

  const loadingMessages = useMemo(() => [
    t('loadingMessage1'),
    t('loadingMessage2'),
    t('loadingMessage3'),
  ], [t]);
  
  const [messageIndex, setMessageIndex] = useState(0);

  useEffect(() => {
    if (!isLoading) return; // Stop cycling when loading is done
    
    const interval = setInterval(() => {
      setMessageIndex((prevIndex) => (prevIndex + 1) % loadingMessages.length);
    }, 1200);
    
    return () => clearInterval(interval);
  }, [isLoading, loadingMessages.length]);

  if (!visible) {
    return null;
  }

  return (
    <div
      className={`fixed inset-0 flex flex-col items-center justify-center z-[100] ${!isLoading ? 'animate-fade-out-slow' : 'animate-fade-in'}`}
      style={{ background: `linear-gradient(to bottom, #1c192d, #0f0f1b)` }}
      onAnimationEnd={() => {
        if (!isLoading) {
          setVisible(false);
        }
      }}
    >
      <LogoIcon className="w-24 h-24 mb-6" style={{ animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite' }} />
      <div className="w-48 h-2 bg-white/10 rounded-full overflow-hidden mb-4">
        <div className="h-full bg-gradient-to-r from-jelly-purple to-jelly-pink rounded-full animate-loading-bar-fill"></div>
      </div>
      <p className="text-white/80 transition-opacity duration-300 text-center px-4">
        {loadingMessages[messageIndex]}
      </p>
    </div>
  );
};

export default LoadingScreen;
