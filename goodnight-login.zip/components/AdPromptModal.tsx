import React from 'react';
import Card from './common/Card';
import { Settings, AdPlacement } from '../types';
import { useTranslations } from '../constants';
import { StarIcon } from './icons/ThemeIcons'; // Using a gentle icon

interface AdPromptModalProps {
    type: AdPlacement | null;
    onConfirm: () => void;
    onClose: () => void;
    isAnimatingOut: boolean;
    settings: Settings;
}

const AdPromptModal: React.FC<AdPromptModalProps> = ({ type, onConfirm, onClose, isAnimatingOut, settings }) => {
    const t = useTranslations(settings.language);

    if (!type) return null;

    const messages = {
        extra_plays: t('adPromptPlaysMessage'),
        extra_wishes: t('adPromptWishesMessage'),
        coin_reward: t('adPromptCoinsMessage'),
    };

    const message = messages[type];
    
    return (
        <div 
            className={`fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 ${isAnimatingOut ? 'animate-fade-out' : 'animate-fade-in'}`}
            onClick={onClose}
        >
            <Card className="w-full max-w-sm p-6 text-center" onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-center mb-4">
                    <StarIcon className="w-10 h-10 text-yellow-300 animate-pulse" />
                </div>
                <h2 className="text-xl font-bold text-yellow-200 mb-4">{t('adPromptTitle')}</h2>
                <p className="text-white/90 leading-relaxed mb-6">
                    {message}
                </p>
                 <div className="flex flex-col sm:flex-row gap-3 justify-center">
                    <button
                        onClick={onClose}
                        className="px-6 py-2 bg-white/10 hover:bg-white/20 rounded-full backdrop-blur-sm transition-all duration-300 text-sm"
                    >
                        {t('adPromptCancel')}
                    </button>
                    <button
                        onClick={onConfirm}
                        className="px-6 py-2 bg-jelly-purple/80 hover:bg-jelly-purple rounded-full backdrop-blur-sm transition-all duration-300 font-semibold"
                    >
                        {t('adPromptConfirm')}
                    </button>
                </div>
            </Card>
        </div>
    );
};

export default AdPromptModal;