import React, { useState } from 'react';
import Card from './common/Card';
import { Settings, SentWish, ReceivedWish } from '../types';
import { useTranslations } from '../constants';
import { PaperPlaneIcon, StarIcon, PlanetIcon } from './icons/ThemeIcons';

interface StarrySkyLogbookProps {
    sentWishes: SentWish[];
    receivedWishes: ReceivedWish[];
    onGenerateEcho: (wishId: string) => Promise<boolean>;
    settings: Settings;
}

const WishCard: React.FC<{
    wish: SentWish;
    onGenerateEcho: (wishId: string) => Promise<boolean>;
    settings: Settings;
}> = ({ wish, onGenerateEcho, settings }) => {
    const t = useTranslations(settings.language);
    const [isRevealed, setIsRevealed] = useState(false);
    const [isReturning, setIsReturning] = useState(false);

    const timeSinceSent = Date.now() - wish.timestamp;
    const canReturn = timeSinceSent > 24 * 60 * 60 * 1000; // 24 hours

    const handleReturnClick = async () => {
        setIsReturning(true);
        const success = await onGenerateEcho(wish.id);
        if (success) {
            setIsRevealed(true);
        }
        setIsReturning(false);
    };

    const formattedDate = new Date(wish.timestamp).toLocaleDateString(settings.language === 'zh' ? 'zh-CN' : 'en-US', {
        month: 'short',
        day: 'numeric'
    });

    if (wish.status === 'returned') {
        return (
            <Card className={`p-4 transition-all duration-500 ${isRevealed ? 'bg-jelly-pink/20' : ''}`}>
                <p className="text-white/90 text-sm">"{wish.text}"</p>
                <div className="mt-2 h-px bg-white/10" />
                {!isRevealed ? (
                    <button onClick={() => setIsRevealed(true)} className="mt-2 text-sm text-jelly-pink font-semibold w-full text-left">
                        {t('viewEcho')}
                    </button>
                ) : (
                    <div className="mt-2 text-sm text-yellow-200 animate-fade-in">
                        <p className="italic">{wish.echo || t('echoFallback')}</p>
                    </div>
                )}
                 <p className="text-xs text-right text-white/40 mt-1">{formattedDate}</p>
            </Card>
        );
    }
    
    // Traveling Wish
    return (
         <Card className="p-4 bg-white/5">
            <p className="text-white/60 text-sm italic">"{wish.text}"</p>
            <div className="mt-2 h-px bg-white/10" />
            <div className="flex justify-between items-center mt-2">
                <p className="text-xs text-white/40">{formattedDate}</p>
                {canReturn ? (
                     <button onClick={handleReturnClick} disabled={isReturning} className="text-sm text-jelly-purple font-semibold flex items-center gap-1 disabled:opacity-50">
                        {isReturning ? (
                            <div className="w-4 h-4 border-2 border-white/50 border-t-white rounded-full animate-spin"></div>
                        ) : '🌠'}
                         {isReturning ? t('receiving') : t('callEcho')}
                    </button>
                ) : (
                    <p className="text-xs text-sky-300/60">{t('travelingInSpace')}</p>
                )}
            </div>
        </Card>
    );
};

const StarrySkyLogbook: React.FC<StarrySkyLogbookProps> = ({ sentWishes, receivedWishes, onGenerateEcho, settings }) => {
    const [activeTab, setActiveTab] = useState<'sent' | 'received'>('sent');
    const t = useTranslations(settings.language);

    const sortedSentWishes = [...sentWishes].sort((a, b) => b.timestamp - a.timestamp);
    const sortedReceivedWishes = [...receivedWishes].sort((a, b) => b.timestamp - a.timestamp);

    return (
        <div className="flex flex-col items-center w-full h-full max-w-md mx-auto relative">
             <div className="absolute inset-0 z-0">
                {Array.from({ length: 50 }).map((_, i) => (
                    <div key={i} className="absolute bg-white rounded-full animate-twinkle" style={{ 
                        left: `${Math.random() * 100}%`, 
                        top: `${Math.random() * 100}%`, 
                        width: `${Math.random() * 1.5 + 0.5}px`, 
                        height: `${Math.random() * 1.5 + 0.5}px`, 
                        animationDelay: `${Math.random() * 5}s`,
                        animationDuration: `${Math.random() * 5 + 3}s`
                    }} />
                ))}
            </div>

            <div className="relative z-10 w-full flex flex-col h-full">
                <h1 className="text-3xl font-bold text-white mb-4 text-center flex-shrink-0">{t('myStarrySkyDiary')}</h1>
                
                <div className="w-full flex justify-center mb-4 flex-shrink-0">
                    <div className="flex bg-black/20 p-1 rounded-full">
                        <button
                            onClick={() => setActiveTab('sent')}
                            className={`px-4 py-2 text-sm rounded-full transition-colors duration-300 w-32 flex items-center justify-center gap-2 ${activeTab === 'sent' ? 'bg-jelly-pink' : 'text-white/70'}`}
                        >
                            <PaperPlaneIcon className="w-4 h-4"/> {t('mySentWishes')}
                        </button>
                         <button
                            onClick={() => setActiveTab('received')}
                            className={`px-4 py-2 text-sm rounded-full transition-colors duration-300 w-32 flex items-center justify-center gap-2 ${activeTab === 'received' ? 'bg-jelly-pink' : 'text-white/70'}`}
                        >
                            <StarIcon className="w-4 h-4"/> {t('myReceivedWishes')}
                        </button>
                    </div>
                </div>

                <div className="w-full flex-grow overflow-y-auto space-y-3 pr-1 pb-4">
                   {activeTab === 'sent' && (
                       sortedSentWishes.length > 0 ? sortedSentWishes.map(wish => (
                           <WishCard key={wish.id} wish={wish} onGenerateEcho={onGenerateEcho} settings={settings} />
                       )) : (
                           <p className="text-center text-white/60 pt-10">{t('noWishesSentYet')}</p>
                       )
                   )}
                   {activeTab === 'received' && (
                       sortedReceivedWishes.length > 0 ? sortedReceivedWishes.map(wish => (
                           <Card key={wish.id} className="p-4 bg-jelly-purple/10">
                               <p className="text-white/90 text-sm">"{wish.text}"</p>
                               <p className="text-xs text-right text-white/40 mt-1">
                                   {new Date(wish.timestamp).toLocaleDateString(settings.language === 'zh' ? 'zh-CN' : 'en-US', {
                                        month: 'short',
                                        day: 'numeric'
                                    })}
                               </p>
                           </Card>
                       )) : (
                           <p className="text-center text-white/60 pt-10">{t('noWishesReceivedYet')}</p>
                       )
                   )}
                </div>
            </div>
        </div>
    );
};

export default StarrySkyLogbook;