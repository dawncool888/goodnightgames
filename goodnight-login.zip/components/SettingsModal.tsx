import React from 'react';
import Card from './common/Card';
import { Settings, Language, TranslationKey } from '../types';
import { useTranslations, SHOP_ITEMS } from '../constants';
import { PaperPlaneIcon } from './icons/ThemeIcons';

interface SettingsModalProps {
    settings: Settings;
    setSettings: React.Dispatch<React.SetStateAction<Settings>>;
    onClose: () => void;
    isAnimatingOut: boolean;
    unlockedItems: string[];
}

const Toggle: React.FC<{ label: string; enabled: boolean; onChange: (enabled: boolean) => void }> = ({ label, enabled, onChange }) => (
    <div className="flex items-center justify-between w-full">
        <span className="text-white/80">{label}</span>
        <button
            onClick={() => onChange(!enabled)}
            className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors duration-300 focus:outline-none ${
                enabled ? 'bg-jelly-purple' : 'bg-white/20'
            }`}
        >
            <span
                className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform duration-300 ${
                    enabled ? 'translate-x-6' : 'translate-x-1'
                }`}
            />
        </button>
    </div>
);

const LanguageSelector: React.FC<{ language: Language; onChange: (lang: Language) => void, t: (key: any) => string }> = ({ language, onChange, t }) => (
    <div className="flex items-center justify-between w-full">
        <span className="text-white/80">{t('language')}</span>
        <div className="flex bg-white/10 rounded-full p-1">
            <button
                onClick={() => onChange('zh')}
                className={`px-3 py-1 text-sm rounded-full transition-colors duration-300 ${language === 'zh' ? 'bg-jelly-pink' : 'text-white/70'}`}
            >
                中文
            </button>
            <button
                onClick={() => onChange('en')}
                className={`px-3 py-1 text-sm rounded-full transition-colors duration-300 ${language === 'en' ? 'bg-jelly-pink' : 'text-white/70'}`}
            >
                EN
            </button>
        </div>
    </div>
);

const ThemeSelector: React.FC<{
    activeThemeId: string;
    unlockedItemIds: string[];
    onSelect: (themeId: string) => void;
    settings: Settings;
}> = ({ activeThemeId, unlockedItemIds, onSelect, settings }) => {
    const t = useTranslations(settings.language);
    const unlockedThemes = SHOP_ITEMS.filter(item => item.category === 'theme' && unlockedItemIds.includes(item.id));
    
    return (
         <div className="flex items-center justify-between w-full">
            <span className="text-white/80">{t('activeTheme')}</span>
            <select
                value={activeThemeId}
                onChange={(e) => onSelect(e.target.value)}
                className="bg-white/10 rounded-full p-1 px-3 text-sm text-white/90 border border-transparent focus:outline-none focus:ring-2 focus:ring-jelly-pink"
            >
                {unlockedThemes.map(theme => (
                    <option key={theme.id} value={theme.id}>
                        {t(theme.id as TranslationKey)}
                    </option>
                ))}
            </select>
        </div>
    );
};


const SettingsModal: React.FC<SettingsModalProps> = ({ settings, setSettings, onClose, isAnimatingOut, unlockedItems }) => {
    const t = useTranslations(settings.language);
    const feedbackEmail = "user-feedback-address@example.com";
    const emailSubject = "A Whisper for Jelly (Good Night Mini-Games Feedback)";

    return (
        <div 
            className={`fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 ${isAnimatingOut ? 'animate-fade-out' : 'animate-fade-in'}`}
            onClick={onClose}
        >
            <Card className="w-full max-w-sm p-6" onClick={(e) => e.stopPropagation()}>
                <h2 className="text-2xl font-bold text-center mb-6">{t('settings')}</h2>
                <div className="space-y-4">
                     <LanguageSelector 
                        language={settings.language}
                        onChange={(lang) => setSettings(s => ({ ...s, language: lang }))}
                        t={t}
                    />
                    <Toggle 
                        label={t('backgroundMusic')} 
                        enabled={settings.music} 
                        onChange={(enabled) => setSettings(s => ({ ...s, music: enabled }))} 
                    />
                    <Toggle 
                        label={t('soundEffects')} 
                        enabled={settings.sfx} 
                        onChange={(enabled) => setSettings(s => ({ ...s, sfx: enabled }))} 
                    />
                     <ThemeSelector
                        activeThemeId={settings.activeTheme}
                        unlockedItemIds={unlockedItems}
                        onSelect={(themeId) => setSettings(s => ({ ...s, activeTheme: themeId }))}
                        settings={settings}
                    />
                     <a
                        href={`mailto:${feedbackEmail}?subject=${encodeURIComponent(emailSubject)}`}
                        className="flex items-center justify-between w-full text-white/80 hover:text-white transition-colors pt-2"
                     >
                        <span>{t('whisperToJelly')}</span>
                        <PaperPlaneIcon className="w-5 h-5" />
                    </a>
                </div>
                 <div className="mt-8 text-center">
                    <button
                        onClick={onClose}
                        className="px-8 py-2 bg-jelly-purple/80 hover:bg-jelly-purple rounded-full backdrop-blur-sm transition-all duration-300"
                    >
                        {t('done')}
                    </button>
                </div>
            </Card>
        </div>
    );
};

export default SettingsModal;