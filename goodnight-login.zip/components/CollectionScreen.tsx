import React, { useMemo, useCallback } from 'react';
import Card from './common/Card';
// FIX: Added translations to imports
import { ALL_STICKERS, SHOP_ITEMS, useTranslations, translations } from '../constants';
// FIX: Added TranslationKey to type imports
import type { Sticker, GameState, Settings, GameStats, TranslationKey } from '../types';
import { LockedIcon } from './icons/ThemeIcons';

interface CollectionScreenProps {
  unlockedStickers: string[];
  sessionHistory: GameState[];
  sentWishesCount: number;
  receivedWishesCount: number;
  settings: Settings;
}

const CollectionScreen: React.FC<CollectionScreenProps> = ({ unlockedStickers, sessionHistory, sentWishesCount, receivedWishesCount, settings }) => {
  const t = useTranslations(settings.language);

  const calculateStats = useCallback((history: GameState[], sentCount: number, receivedCount: number): GameStats => {
    const gameStats = history.reduce((acc, session) => {
        acc.totalClicks += session.clicks;
        acc.totalDuration += session.duration;
        acc.sessionsPlayed += 1;

        const theme = SHOP_ITEMS.find(t => t.id === session.themeId);
        if (!theme || theme.category !== 'game') return acc;
        
        // FIX: Use translations to get the Chinese theme name, as `theme.name` does not exist.
        const themeName = translations.zh[theme.id as TranslationKey]; // Use Chinese name as key
        acc.clicksPerTheme[themeName] = (acc.clicksPerTheme[themeName] || 0) + session.clicks;
        acc.sessionsPerTheme[themeName] = (acc.sessionsPerTheme[themeName] || 0) + 1;
        return acc;
    }, {
        totalClicks: 0,
        totalDuration: 0,
        sessionsPlayed: 0,
        clicksPerTheme: {},
        sessionsPerTheme: {},
        daysPlayed: new Set(history.map(s => s.date)).size,
        wishesSent: 0,
        wishesReceived: 0,
    });

    gameStats.wishesSent = sentCount;
    gameStats.wishesReceived = receivedCount;

    return gameStats;

  }, []);

  const stats = useMemo(() => calculateStats(sessionHistory, sentWishesCount, receivedWishesCount), [sessionHistory, sentWishesCount, receivedWishesCount, calculateStats]);

  return (
    <Card className="w-full max-w-md p-6 overflow-y-auto no-scrollbar" style={{maxHeight: 'calc(100% - 2rem)'}}>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-4">
          {ALL_STICKERS.map((sticker: Sticker) => {
            const isUnlocked = unlockedStickers.includes(sticker.id);
            return (
              <div
                key={sticker.id}
                className="relative group flex flex-col items-center justify-center p-2 aspect-square rounded-xl transition-all duration-300"
              >
                <div className={`flex-grow flex items-center justify-center w-full h-full rounded-lg ${isUnlocked ? 'bg-white/10' : 'bg-black/30'}`}>
                    {isUnlocked ? (
                        <sticker.icon className="w-12 h-12 text-white" />
                    ) : (
                        <LockedIcon className="w-10 h-10 text-white/20" />
                    )}
                </div>
                {/* FIX: Use sticker.name(t) to get the sticker name, resolving a property-not-found error. */}
                <span className={`font-semibold text-xs mt-1 ${
                  isUnlocked ? 'text-white/90' : 'text-white/40'
                }`}>
                  {isUnlocked ? sticker.name(t) : t('lockedSticker')}
                </span>
                {!isUnlocked && (
                    <div className="absolute bottom-full mb-2 w-max max-w-xs p-2 text-xs text-white bg-black/70 rounded-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
                        {/* FIX: Pass the translation function `t` instead of language string to `getUnlockDescription`, resolving a type error. */}
                        {sticker.getUnlockDescription(t)}
                    </div>
                )}
              </div>
            );
          })}
        </div>
      </Card>
  );
};

export default CollectionScreen;
