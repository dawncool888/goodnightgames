import React, { useState, useEffect } from 'react';
import Card from './common/Card';
import { Settings } from '../types';
import { useTranslations } from '../constants';
import { MoonIcon } from './icons/ThemeIcons';

interface AdLimitModalProps {
    onClose: () => void;
    isAnimatingOut: boolean;
    settings: Settings;
}

const AdLimitModal: React.FC<AdLimitModalProps> = ({ onClose, isAnimatingOut, settings }) => {
    const t = useTranslations(settings.language);
    const [timeLeft, setTimeLeft] = useState('');

    useEffect(() => {
        const calculateTimeLeft = () => {
            const now = new Date();
            const tomorrow = new Date();
            tomorrow.setDate(now.getDate() + 1);
            tomorrow.setHours(0, 0, 0, 0);

            const difference = tomorrow.getTime() - now.getTime();

            const hours = Math.floor((difference / (1000 * 60 * 60)) % 24);
            const minutes = Math.floor((difference / 1000 / 60) % 60);
            const seconds = Math.floor((difference / 1000) % 60);
            
            return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        };

        setTimeLeft(calculateTimeLeft());
        const timer = setInterval(() => {
            setTimeLeft(calculateTimeLeft());
        }, 1000);

        return () => clearInterval(timer);
    }, []);
    
    return (
        <div 
            className={`fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 ${isAnimatingOut ? 'animate-fade-out' : 'animate-fade-in'}`}
            onClick={onClose}
        >
            <Card className="w-full max-w-sm p-6 text-center" onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-center mb-4">
                    <MoonIcon className="w-10 h-10 text-sky-300" />
                </div>
                <h2 className="text-xl font-bold text-sky-200 mb-4">{t('adLimitTitle')}</h2>
                <p className="text-white/90 leading-relaxed mb-6">
                    {t('adLimitMessage')}
                </p>
                <div className="bg-white/5 rounded-lg py-2 px-4">
                    <span className="text-sm text-white/70">{t('adLimitResetTime')}</span>
                    <span className="ml-2 font-bold text-lg text-white tracking-wider">{timeLeft}</span>
                </div>
                 <div className="mt-6 text-center">
                    <button
                        onClick={onClose}
                        className="px-8 py-2 bg-jelly-purple/80 hover:bg-jelly-purple rounded-full backdrop-blur-sm transition-all duration-300"
                    >
                        {t('done')}
                    </button>
                </div>
            </Card>
        </div>
    );
};

export default AdLimitModal;