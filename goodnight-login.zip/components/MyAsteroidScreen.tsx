import React, { useState, useRef, useEffect, useMemo, useLayoutEffect } from 'react';
import { Settings, PlacedDecoration, ShopItem, TranslationKey, DecorationInventory } from '../types';
import { useTranslations, SHOP_ITEMS, HEALING_TIPS, ZODIAC_CONSTELLATIONS } from '../constants';
import { ChevronRightIcon } from './icons/ThemeIcons';
import Card from './common/Card';

interface MyAsteroidScreenProps {
    settings: Settings;
    setSettings: React.Dispatch<React.SetStateAction<Settings>>;
    placedDecorations: PlacedDecoration[];
    setPlacedDecorations: React.Dispatch<React.SetStateAction<PlacedDecoration[]>>;
}

const NUM_SLOTS = 8;
const ASTEROID_SIZE = 300; // in pixels

// --- Fading Constellations Component ---
const FadingConstellations: React.FC = () => {
    const constellations = useMemo(() => ZODIAC_CONSTELLATIONS, []);
    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentIndex(Math.floor(Math.random() * constellations.length));
        }, 10000); // Change constellation every 10 seconds
        return () => clearInterval(timer);
    }, [constellations.length]);

    return (
        <div className="absolute inset-0 z-0 pointer-events-none flex items-center justify-center">
            <svg
                key={currentIndex}
                viewBox="-100 -100 200 200"
                className="w-1/2 h-1/2 text-white/50 animate-constellation-draw"
                stroke="currentColor"
                strokeWidth="1"
                fill="none"
                strokeLinecap="round"
                strokeLinejoin="round"
            >
                <path d={constellations[currentIndex].path} />
            </svg>
        </div>
    );
};


const MyAsteroidScreen: React.FC<MyAsteroidScreenProps> = ({ settings, setSettings, placedDecorations, setPlacedDecorations }) => {
    const t = useTranslations(settings.language);
    const [rotation, setRotation] = useState(0);
    const [isDragging, setIsDragging] = useState(false);
    const [dragStartX, setDragStartX] = useState(0);
    const [startRotation, setStartRotation] = useState(0);
    
    const [draggedItem, setDraggedItem] = useState<ShopItem | null>(null);
    const [draggedOverSlot, setDraggedOverSlot] = useState<number | null>(null);

    const [isInventoryCollapsed, setIsInventoryCollapsed] = useState(false);
    
    const [tutorialStep, setTutorialStep] = useState(
      !settings.hasDecoratedBefore && placedDecorations.length === 0 ? 1 : 0
    );

    const [activeTip, setActiveTip] = useState<{ fireflyId: number; content: string; position: { top: number; left: number } } | null>(null);
    const bubbleRef = useRef<HTMLDivElement>(null);

    const animationFrameId = useRef<number | undefined>(undefined);
    const [reclaimingItem, setReclaimingItem] = useState<{ itemId: string; slotId: number; startRect: DOMRect } | null>(null);


    const nebulae = useMemo(() => Array.from({ length: 3 }, (_, i) => ({
        id: i,
        top: `${10 + Math.random() * 60}%`,
        left: `${10 + Math.random() * 70}%`,
        width: `${100 + Math.random() * 150}px`,
        height: `${80 + Math.random() * 120}px`,
        color: ['rgba(244, 114, 182, 0.5)', 'rgba(139, 92, 246, 0.5)', 'rgba(52, 211, 153, 0.5)'][i],
        animationDelay: `${i * 3}s`,
    })), []);

    const fireflies = useMemo(() => Array.from({ length: 5 }, (_, i) => ({
        id: i,
        top: `${Math.random() * 90}%`,
        left: `${Math.random() * 90}%`,
        animationDuration: `${15 + Math.random() * 10}s`,
        animationDelay: `${i * 2}s`,
    })), []);


    useEffect(() => {
        const animate = () => {
            if (!isDragging) {
                setRotation(r => r + 0.05);
            }
            animationFrameId.current = requestAnimationFrame(animate);
        };
        animationFrameId.current = requestAnimationFrame(animate);
        return () => {
            if (animationFrameId.current) {
                cancelAnimationFrame(animationFrameId.current);
            }
        };
    }, [isDragging]);


    const handleMouseDown = (e: React.MouseEvent) => {
        setIsDragging(true);
        setDragStartX(e.clientX);
        setStartRotation(rotation);
    };

    const handleMouseMove = (e: React.MouseEvent) => {
        if (!isDragging) return;
        const dx = e.clientX - dragStartX;
        const newRotation = startRotation + dx * 0.5;
        setRotation(newRotation);
    };

    const handleMouseUp = () => {
        setIsDragging(false);
    };
    
    const handleTouchStart = (e: React.TouchEvent) => {
        setIsDragging(true);
        setDragStartX(e.touches[0].clientX);
        setStartRotation(rotation);
    };

    const handleTouchMove = (e: React.TouchEvent) => {
        if (!isDragging) return;
        const dx = e.touches[0].clientX - dragStartX;
        const newRotation = startRotation + dx * 0.5;
        setRotation(newRotation);
    };

    const handleTouchEnd = () => {
        setIsDragging(false);
    };

    const handleDragStart = (e: React.DragEvent, item: ShopItem) => {
        if ((settings.decorationInventory[item.id] || 0) <= 0) {
            e.preventDefault();
            return;
        }
        setDraggedItem(item);
        e.dataTransfer.effectAllowed = 'move';
        const img = new Image();
        img.src = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
        e.dataTransfer.setData('text/plain', item.id);
        e.dataTransfer.setDragImage(img, 0, 0);
        if (tutorialStep === 1) setTutorialStep(2);
    };
    
    const handleDragOver = (e: React.DragEvent, slotId: number) => {
        e.preventDefault();
        setDraggedOverSlot(slotId);
    };

    const handleDrop = (e: React.DragEvent, slotId: number) => {
        e.preventDefault();
        if (draggedItem) {
            setPlacedDecorations(prev => {
                const withoutOld = prev.filter(d => d.slotId !== slotId);
                return [...withoutOld, { itemId: draggedItem.id, slotId }];
            });
            
            setSettings(s => {
                const newInventory = { ...s.decorationInventory };
                newInventory[draggedItem.id] = (newInventory[draggedItem.id] || 1) - 1;
                return { ...s, decorationInventory: newInventory };
            });

            if (tutorialStep === 2) {
              setTimeout(() => setTutorialStep(3), 500);
            }
        }
        setDraggedItem(null);
        setDraggedOverSlot(null);
    };
    
    const handleReclaim = (slotId: number, itemId: string, e: React.MouseEvent<HTMLButtonElement>) => {
        const rect = e.currentTarget.getBoundingClientRect();
        setReclaimingItem({ itemId, slotId, startRect: rect });
    };

    const onReclaimAnimationEnd = () => {
        if (!reclaimingItem) return;

        setSettings(s => {
            const newInventory: DecorationInventory = { ...s.decorationInventory };
            newInventory[reclaimingItem.itemId] = (newInventory[reclaimingItem.itemId] || 0) + 1;
            return { ...s, decorationInventory: newInventory };
        });
        
        setPlacedDecorations(prev => prev.filter(d => d.slotId !== reclaimingItem.slotId));

        setReclaimingItem(null);

        if (tutorialStep === 3) {
            setTutorialStep(0);
            setSettings(s => ({...s, hasDecoratedBefore: true}));
        }
    };
    
    const handleFireflyClick = (e: React.MouseEvent<HTMLDivElement>, fireflyId: number) => {
        e.stopPropagation();
        if (activeTip?.fireflyId === fireflyId) {
            setActiveTip(null);
        } else {
            const tips = HEALING_TIPS[settings.language];
            const randomTip = tips[Math.floor(Math.random() * tips.length)];
            const rect = e.currentTarget.getBoundingClientRect();
            setActiveTip({
                fireflyId,
                content: randomTip,
                position: { top: rect.top, left: rect.left + rect.width / 2 }
            });
        }
    };

    useLayoutEffect(() => {
        if (activeTip && bubbleRef.current) {
            const bubble = bubbleRef.current;
            const rect = bubble.getBoundingClientRect();
            const screenWidth = window.innerWidth;
            
            let finalTransform = 'translate(-50%, -100%)';

            if (rect.right > screenWidth - 10) {
                const overflow = rect.right - (screenWidth - 10);
                finalTransform = `translate(calc(-50% - ${overflow}px), -100%)`;
            } else if (rect.left < 10) {
                const underflow = 10 - rect.left;
                finalTransform = `translate(calc(-50% + ${underflow}px), -100%)`;
            }

            bubble.style.transform = finalTransform;
        }
    }, [activeTip]);


    const getSlotPosition = (slotId: number, currentRotation: number) => {
        const angle = (slotId / NUM_SLOTS) * 360 + currentRotation;
        const radian = (angle * Math.PI) / 180;
        const radius = ASTEROID_SIZE / 2 * 0.85; 
        const x = ASTEROID_SIZE / 2 + radius * Math.cos(radian);
        const y = ASTEROID_SIZE / 2 + radius * Math.sin(radian);
        const scale = 0.6 + 0.4 * Math.sin(radian + Math.PI/2); 
        const zIndex = Math.floor(scale * 100);
        return { x, y, scale, zIndex };
    };
    
    const getAnimationClass = (style: ShopItem['animationStyle']) => {
        switch (style) {
            case 'swim': return 'animate-swim';
            case 'pulse': return 'animate-pulse-light';
            case 'shimmer': return 'animate-shimmer';
            case 'sway': return 'animate-gentle-sway';
            case 'spin': return 'animate-slow-spin';
            default: return '';
        }
    };
    
    useEffect(() => {
        // FIX: Replaced `NodeJS.Timeout` with `ReturnType<typeof setTimeout>` to use the correct browser-compatible type for the `setTimeout` return value, resolving a TypeScript namespace error.
        let timer: ReturnType<typeof setTimeout>;
        if (tutorialStep === 1 || tutorialStep === 3) {
            timer = setTimeout(() => {
                setTutorialStep(0);
                if(tutorialStep === 3) {
                    setSettings(s => ({...s, hasDecoratedBefore: true}));
                }
            }, 5000);
        }
        return () => clearTimeout(timer);
    }, [tutorialStep, setSettings]);

    return (
        <div className="w-full h-full flex flex-col items-center justify-center text-center relative overflow-hidden" onClick={() => setActiveTip(null)}>
            <div className="absolute inset-0 z-0 pointer-events-none">
                {nebulae.map(n => (
                    <div key={n.id} className="absolute rounded-full filter blur-3xl animate-pulse-opacity" style={{
                        top: n.top,
                        left: n.left,
                        width: n.width,
                        height: n.height,
                        background: n.color,
                        animationDelay: n.animationDelay,
                    }}/>
                ))}
                 {fireflies.map(f => (
                    <div 
                        key={f.id}
                        onClick={(e) => handleFireflyClick(e, f.id)}
                        className="absolute w-2 h-2 rounded-full bg-yellow-200 shadow-[0_0_8px_2px_#fde047] animate-float-around cursor-pointer" style={{
                        top: f.top,
                        left: f.left,
                        animationDuration: f.animationDuration,
                        animationDelay: f.animationDelay,
                        pointerEvents: 'auto'
                    }}/>
                ))}
                <FadingConstellations />
            </div>

            {activeTip && (
                <div
                    ref={bubbleRef}
                    className="fixed w-max max-w-[calc(100vw-20px)] sm:max-w-[60vw] md:max-w-[250px] p-2 text-xs text-white bg-black/70 rounded-md chat-bubble z-50 pointer-events-none"
                    style={{
                        top: activeTip.position.top,
                        left: activeTip.position.left,
                        transform: 'translate(-50%, -100%)',
                        marginBottom: '10px'
                    }}
                >
                    {activeTip.content}
                </div>
            )}

            {reclaimingItem && (() => {
                const item = SHOP_ITEMS.find(i => i.id === reclaimingItem.itemId);
                if (!item) return null;
                return (
                    <div
                        className="fixed animate-fly-to-inventory pointer-events-none z-50"
                        style={{
                            left: reclaimingItem.startRect.left,
                            top: reclaimingItem.startRect.top,
                            width: reclaimingItem.startRect.width,
                            height: reclaimingItem.startRect.height,
                        }}
                        onAnimationEnd={onReclaimAnimationEnd}
                    >
                         <item.icon className={`w-full h-full ${item.color}`} />
                    </div>
                );
            })()}

            
            <div className="flex-grow flex items-center justify-center z-10">
                <div 
                    className="relative cursor-grab active:cursor-grabbing"
                    style={{ width: `${ASTEROID_SIZE}px`, height: `${ASTEROID_SIZE}px`, transform: `rotate(${rotation % 360}deg)` }}
                    onMouseDown={handleMouseDown}
                    onMouseMove={handleMouseMove}
                    onMouseUp={handleMouseUp}
                    onMouseLeave={handleMouseUp}
                    onTouchStart={handleTouchStart}
                    onTouchMove={handleTouchMove}
                    onTouchEnd={handleTouchEnd}
                >
                    <div className="absolute inset-0 rounded-full bg-gradient-to-br from-slate-600 to-slate-800 shadow-2xl"
                        style={{ transform: `rotate(${-rotation % 360}deg)` }}
                    >
                        <div className="absolute w-16 h-16 rounded-full bg-black/10 top-1/4 left-1/4"></div>
                        <div className="absolute w-8 h-8 rounded-full bg-black/20 bottom-1/3 right-1/4"></div>
                        <div className="absolute w-12 h-12 rounded-full bg-black/15 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"></div>
                    </div>

                    {Array.from({ length: NUM_SLOTS }, (_, i) => {
                        const { x, y, scale, zIndex } = getSlotPosition(i, 0);
                        const decoration = placedDecorations.find(d => d.slotId === i);
                        const item = decoration ? SHOP_ITEMS.find(item => item.id === decoration.itemId) : null;
                        
                        return (
                             <div 
                                key={i}
                                onDragOver={(e) => handleDragOver(e, i)}
                                onDrop={(e) => handleDrop(e, i)}
                                onDragLeave={() => setDraggedOverSlot(null)}
                                className="absolute"
                                style={{
                                    left: `${x}px`,
                                    top: `${y}px`,
                                    transform: `translate(-50%, -50%) scale(${scale}) rotate(${-rotation % 360}deg)`,
                                    zIndex: zIndex,
                                    transition: 'opacity 0.3s'
                                }}
                            >
                                {item ? (
                                    <button
                                        onClick={(e) => handleReclaim(i, item.id, e)}
                                        style={{ opacity: reclaimingItem?.slotId === i ? 0 : 1 }}
                                        className={`relative group transition-transform duration-200 hover:scale-110 ${getAnimationClass(item.animationStyle)}`}
                                    >
                                        <item.icon className={`w-16 h-16 ${item.color}`} style={{ filter: `drop-shadow(0 0 8px ${item.color})`, '--glow-color': item.color } as React.CSSProperties} />
                                         <div className="absolute inset-0 bg-red-500/80 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                             <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                         </div>
                                    </button>
                                ) : (
                                     <div className={`w-10 h-10 border-2 border-dashed rounded-full transition-all duration-200 border-white/20
                                        ${tutorialStep === 2 ? 'animate-pulse border-jelly-pink' : ''}
                                        ${draggedOverSlot === i ? 'border-jelly-pink bg-jelly-pink/20 scale-125' : ''}
                                     `}/>
                                )}
                            </div>
                        );
                    })}
                </div>
            </div>

            <div className={`fixed right-0 top-1/2 -translate-y-1/2 h-3/4 max-h-[500px] w-24 p-2 z-20 transition-transform duration-500 ease-in-out ${isInventoryCollapsed ? 'translate-x-full' : 'translate-x-0'}`}>
                <button 
                  onClick={() => setIsInventoryCollapsed(c => !c)} 
                  className={`absolute -left-5 top-1/2 -translate-y-1/2 w-6 h-10 bg-black/20 backdrop-blur-md rounded-l-lg flex items-center justify-center border border-r-0 border-white/10 z-10 transition-transform duration-500 ${isInventoryCollapsed ? 'translate-x-0' : '-translate-x-1'}`}
                >
                    <ChevronRightIcon className={`w-4 h-4 transition-transform duration-300 ${isInventoryCollapsed ? 'rotate-180' : ''}`} />
                </button>
                <Card className="w-full h-full relative">
                    <div className="h-full overflow-y-auto space-y-2 no-scrollbar">
                        {SHOP_ITEMS.filter(i => i.category === 'decoration').map((item) => {
                            const count = settings.decorationInventory[item.id] || 0;
                            const hasItem = count > 0;
                            return (
                                <div
                                    key={item.id}
                                    draggable={hasItem}
                                    onDragStart={(e) => handleDragStart(e, item)}
                                    className={`w-20 h-20 rounded-lg flex-shrink-0 flex items-center justify-center relative ${
                                        hasItem ? 'cursor-grab active:cursor-grabbing' : 'opacity-40'
                                    } ${tutorialStep === 1 && item.id === 'glowing-tree' ? 'animate-pulse bg-jelly-pink/30' : ''}`}
                                    style={{ backgroundColor: hasItem ? item.bgColor : 'rgba(255,255,255,0.05)' }}
                                >
                                    <item.icon className={`w-12 h-12 ${item.color}`} />
                                    {hasItem && (
                                        <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-jelly-pink rounded-full text-xs font-bold flex items-center justify-center border-2 border-slate-700">
                                            {count}
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                </Card>
            </div>

            {tutorialStep === 1 && (
                <div className="fixed top-1/3 right-28 flex items-center gap-2 z-30 animate-fade-in pointer-events-none">
                     <Card className="w-40 text-center p-2">
                         <p className="text-xs">{t('dragToDecorate')}</p>
                    </Card>
                    <div className="w-8 h-8 text-white" style={{ animation: 'point-right 1.5s ease-in-out infinite' }}>
                       <ChevronRightIcon />
                    </div>
                </div>
            )}
             {tutorialStep === 3 && (
                <Card className="absolute top-1/2 -translate-y-1/2 left-2 w-40 text-center p-2 z-30 animate-fade-in">
                     <p className="text-xs">{t('tutorialDragReturn')}</p>
                </Card>
            )}
        </div>
    );
};

export default MyAsteroidScreen;