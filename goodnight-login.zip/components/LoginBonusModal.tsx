import React from 'react';
import Card from './common/Card';
import { Settings } from '../types';
import { useTranslations } from '../constants';
import { GiftIcon, CoinIcon } from './icons/ThemeIcons';

interface LoginBonusModalProps {
    onClose: () => void;
    isAnimatingOut: boolean;
    settings: Settings;
    bonusAmount: number;
}

const LoginBonusModal: React.FC<LoginBonusModalProps> = ({ onClose, isAnimatingOut, settings, bonusAmount }) => {
    const t = useTranslations(settings.language);
    
    return (
        <div 
            className={`fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 ${isAnimatingOut ? 'animate-fade-out' : 'animate-fade-in'}`}
            onClick={onClose}
        >
            <Card className="w-full max-w-sm p-6 text-center" onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-center mb-4">
                    <GiftIcon className="w-12 h-12 text-yellow-300 animate-wobble" style={{animationDuration: '2s'}}/>
                </div>
                <h2 className="text-xl font-bold text-yellow-200 mb-2">{t('loginBonusTitle')}</h2>
                <p className="text-white/90 leading-relaxed mb-4">
                    {t('loginBonusMessage', { amount: bonusAmount })}
                </p>
                <div className="flex items-center justify-center gap-2 bg-black/20 rounded-full px-4 py-2 mb-6">
                    <CoinIcon className="w-6 h-6 text-yellow-400"/>
                    <span className="text-xl font-bold text-yellow-300">+{bonusAmount}</span>
                </div>
                 <div className="text-center">
                    <button
                        onClick={onClose}
                        className="px-8 py-2 bg-jelly-purple/80 hover:bg-jelly-purple rounded-full backdrop-blur-sm transition-all duration-300"
                    >
                        {t('loginBonusConfirm')}
                    </button>
                </div>
            </Card>
        </div>
    );
};

export default LoginBonusModal;