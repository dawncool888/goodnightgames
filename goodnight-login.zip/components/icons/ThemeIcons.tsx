import React from 'react';

// New UI Icons
export const LogoIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-10 h-10', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.64-.11 2.41-.31-3.12-.91-5.41-3.93-5.41-7.42 0-4.49 3.58-8.1 8-8.1.18 0 .35 0 .53.02-1.24-1.92-3.3-3.19-5.53-3.19z" fill="white" />
        <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4c-1.48 0-2.85.43-4.01 1.17" stroke="none"/>
    </svg>
);

export const SheepSettingsIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-8 h-8', ...props }) => (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <g transform="translate(5 10)">
            <ellipse cx="45" cy="65" rx="28" ry="18" fill="white"/>
            <ellipse cx="68" cy="55" rx="18" ry="15" fill="white"/>
            <ellipse cx="25" cy="55" rx="20" ry="16" fill="white"/>
            <ellipse cx="45" cy="40" rx="25" ry="18" fill="white"/>
            
            <g transform="translate(50 35)">
                <ellipse cx="0" cy="0" rx="16" ry="18" fill="#E5E7EB"/>
                <circle cx="-6" cy="2" r="3" fill="#1F2937"/>
                <circle cx="6" cy="2" r="3" fill="#1F2937"/>
            </g>
        </g>
    </svg>
);


export const MoonUiIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-10 h-10', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M12.3,4.9C8.9,4.9,6.1,7.7,6.1,11.1c0,1.8,0.8,3.5,2.1,4.6c-0.1,0-0.2,0-0.3,0c-3.4,0-6.2-2.8-6.2-6.2s2.8-6.2,6.2-6.2c2,0,3.9,1,5.1,2.5C14.3,5.3,13.3,4.9,12.3,4.9z" fillOpacity="0.5"/>
        <path d="M15.4,6.4c-0.8-0.7-1.8-1.1-2.9-1.1c-1,0-2,0.4-2.7,1.1c-0.7,0.7-1.1,1.7-1.1,2.7c0,1,0.4,2,1.1,2.7c0.7,0.7,1.7,1.1,2.7,1.1c1,0,2-0.4,2.7-1.1c0.7-0.7,1.1-1.7,1.1-2.7C16.5,8.1,16.1,7.1,15.4,6.4z" fillOpacity="0.4"/>
        <path d="M12.3,3.3c-4.5,0-8.2,3.7-8.2,8.2c0,3.4,2.1,6.4,5.1,7.6c0,0,0,0,0.1,0c0,0,0,0,0.1,0c0.1,0,0.1,0,0.2,0c3.4,0,6.2-2.8,6.2-6.2c0-1.2-0.3-2.3-0.9-3.3C14.1,8.5,13.2,7.9,12.3,7.6z" fill="none"/>
        <path d="M12.3,3.3C7.8,3.3,4.1,7,4.1,11.5c0,3.4,2.1,6.4,5.1,7.6c0.1,0,0.2,0.1,0.4,0.1c3.4,0,6.2-2.8,6.2-6.2c0-1.2-0.3-2.3-0.9-3.3c-0.6-0.9-1.5-1.6-2.5-1.9C12.4,7.8,12.3,7.8,12.3,7.8C12.2,7.7,12,7.6,11.8,7.5z" fill="none"/>
        <path d="M20.7,14.6c-1.8-1.1-3.9-1.8-6.1-1.8c-0.9,0-1.8,0.1-2.6,0.4c2.6,1.2,4.4,3.8,4.4,6.8c0,0.3,0,0.5-0.1,0.8c2.4-1,4.1-3.2,4.4-5.8C20.9,15,20.8,14.8,20.7,14.6z"/>
    </svg>
);

export const SettingsIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-6 h-6', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M19.14,12.94a2,2,0,0,1,0-1.88l1.48-1.15a1,1,0,0,0,.3-1.27l-1-1.73a1,1,0,0,0-1.27-.49l-1.6.64a2,2,0,0,1-1.9,0L13.5,6.5a1,1,0,0,0-1-1.73,1,1,0,0,0-.27,0l-1.73,1a1,1,0,0,0-.49,1.27l.64,1.6a2,2,0,0,1,0,1.9l-.64,1.6a1,1,0,0,0,.49,1.27l1.73,1a1,1,0,0,0,1.27,0l1.15-1.48a2,2,0,0,1,1.88,0l1.15,1.48a1,1,0,0,0,1.27,0l1.73-1a1,1,0,0,0,.49-1.27l-1.48-1.15Z"/>
        <circle cx="12" cy="12" r="3"/>
    </svg>
);

export const UserIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-6 h-6', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
        <circle cx="12" cy="7" r="4"></circle>
    </svg>
);


export const HomeIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-6 h-6', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
);

export const CollectionIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-6 h-6', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
);

export const ReportIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-6 h-6', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M10 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9.5L14.5 3H10z"/><polyline points="14 3 14 9 20 9"/><path d="M8 17h3"/><path d="M8 13h8"/></svg>
);

export const ShopIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-6 h-6', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
);

export const CoinIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-6 h-6', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><circle cx="12" cy="12" r="8"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="12" y1="3" x2="12" y2="21"/><path d="M12 12c-2.67 0-5-1.33-5-4s2.33-4 5-4 5 1.33 5 4-2.33 4-5 4z"/><path d="M12 12c2.67 0 5 1.33 5 4s-2.33 4-5 4-5-1.33-5-4 2.33-4 5-4z"/></svg>
);

export const GiftIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-6 h-6', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <rect x="3" y="8" width="18" height="4" rx="1"></rect>
        <line x1="12" y1="8" x2="12" y2="21"></line>
        <path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"></path>
        <path d="M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5"></path>
    </svg>
);


export const LogbookIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-5 h-5', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M16 4.08C14.7 3.4 13.2 3 11.5 3 6.25 3 2 7.25 2 12.5S6.25 22 11.5 22c1.7 0 3.2-.4 4.5-1.08"/>
        <circle cx="12.5" cy="10.5" r=".5" fill="currentColor" stroke="none"/>
        <circle cx="15.5" cy="13.5" r=".5" fill="currentColor" stroke="none"/>
    </svg>
);


export const ChevronLeftIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-6 h-6', ...props }) => (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3} {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
    </svg>
);

export const ChevronRightIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-6 h-6', ...props }) => (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3} {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
    </svg>
);

export const EditIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-6 h-6', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" />
    </svg>
);



// Main Game Icons
export const SheepIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <defs>
            <radialGradient id="sheep-blush-fluffy" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(68 53) rotate(90) scale(6)">
                <stop stopColor="#F472B6" stopOpacity="0.5"/>
                <stop offset="1" stopColor="#F472B6" stopOpacity="0"/>
            </radialGradient>
        </defs>
        <g transform="translate(5 10)">
            <ellipse cx="45" cy="65" rx="28" ry="18" fill="#F9FAFB"/>
            <ellipse cx="68" cy="55" rx="18" ry="15" fill="#F9FAFB"/>
            <ellipse cx="25" cy="55" rx="20" ry="16" fill="#F9FAFB"/>
            <ellipse cx="45" cy="40" rx="25" ry="18" fill="#F9FAFB"/>
            
            <g transform="translate(50 35)">
                <ellipse cx="0" cy="0" rx="16" ry="18" fill="#E5E7EB"/>
                <ellipse cx="-5" cy="16" rx="4" ry="2" fill="#D1D5DB" />
                <ellipse cx="5" cy="16" rx="4" ry="2" fill="#D1D5DB" />
                <circle cx="-6" cy="2" r="2.5" fill="#1F2937"/>
                <circle cx="6" cy="2" r="2.5" fill="#1F2937"/>
                <circle cx="18" cy="3" r="6" fill="url(#sheep-blush-fluffy)"/>
            </g>
        </g>
    </svg>
);

export const WoodenFishIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <defs>
            <linearGradient id="wood-gradient" x1="50" y1="10" x2="50" y2="90" gradientUnits="userSpaceOnUse">
                <stop stopColor="#A16207"/>
                <stop offset="1" stopColor="#422006"/>
            </linearGradient>
            <linearGradient id="wood-highlight" x1="50" y1="10" x2="50" y2="90" gradientUnits="userSpaceOnUse">
                <stop stopColor="#FDE047" stopOpacity="0.8"/>
                <stop offset="1" stopColor="#FDE047" stopOpacity="0"/>
            </linearGradient>
        </defs>
        <path d="M90 50C90 72.0914 72.0914 90 50 90C27.9086 90 10 72.0914 10 50C10 38.9329 15.0366 29.0142 22.901 22.0988L50 10L77.099 22.0988C84.9634 29.0142 90 38.9329 90 50Z" fill="url(#wood-gradient)"/>
        <path d="M50 10L77.099 22.0988C84.9634 29.0142 90 38.9329 90 50C90 55 88.5 60 86 64" stroke="url(#wood-highlight)" strokeWidth="3"/>
        <path d="M30 65C35 60 45 60 50 65" stroke="#FDE047" strokeOpacity="0.3" strokeWidth="4" strokeLinecap="round"/>
        <path d="M60 72C65 68 72 68 75 72" stroke="#FDE047" strokeOpacity="0.3" strokeWidth="3" strokeLinecap="round"/>
        <path d="M25 50C30 48 38 48 42 50" stroke="#FDE047" strokeOpacity="0.3" strokeWidth="3" strokeLinecap="round"/>
    </svg>
);

export const WoodenMalletIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <defs>
            <linearGradient id="mallet-handle" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#8c5a3b" />
                <stop offset="100%" stopColor="#5d3a1f" />
            </linearGradient>
            <linearGradient id="mallet-head" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#a16207" />
                <stop offset="100%" stopColor="#78350f" />
            </linearGradient>
        </defs>
        <g transform="rotate(-45 50 50)">
            <rect x="46" y="20" width="8" height="60" rx="4" fill="url(#mallet-handle)" />
            <ellipse cx="50" cy="15" rx="15" ry="10" fill="url(#mallet-head)" />
        </g>
    </svg>
);


export const DandelionIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
         <defs>
            <radialGradient id="dandelion-glow" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(50 50) rotate(90) scale(35)">
                <stop stopColor="white" stopOpacity="0.5"/>
                <stop offset="1" stopColor="white" stopOpacity="0"/>
            </radialGradient>
        </defs>
        <circle cx="50" cy="50" r="35" fill="url(#dandelion-glow)"/>
        <path d="M50 95V55" stroke="white" strokeWidth="3" strokeLinecap="round"/>
        <g transform="translate(50 50)">
            {[...Array(16)].map((_, i) => (
                <g key={i} transform={`rotate(${i * 22.5})`}>
                    <path d="M0 -30 L 0 -40" stroke="white" strokeWidth="2" strokeLinecap="round"/>
                    <circle cx="0" cy="-40" r="3" fill="white"/>
                </g>
            ))}
        </g>
    </svg>
);

export const BubbleIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <defs>
            <radialGradient id="bubble-gradient" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(65 35) rotate(90) scale(50)">
                <stop stopColor="#A5B4FC" />
                <stop offset="1" stopColor="#312E81" stopOpacity="0.5"/>
            </radialGradient>
        </defs>
        <circle cx="50" cy="50" r="40" fill="url(#bubble-gradient)" opacity="0.7"/>
        <path d="M35 35C40 30 50 32 55 40" stroke="white" strokeWidth="4" strokeLinecap="round" opacity="0.8"/>
        <circle cx="70" cy="65" r="5" fill="white" opacity="0.5"/>
    </svg>
);

// New Game Icons for the Shop
export const ConstellationGameIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => <StarIcon className={className} {...props} />;
export const MoonRiverGameIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => <MoonIcon className={className} {...props} />;
export const CloudSeaGameIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => <CloudIcon className={className} {...props} />;
export const SecretGardenGameIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => <LeafIcon className={className} {...props} />;

// New Skin Icons
export const DreamSheepIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <defs>
            <filter id="glow-purple">
                <feGaussianBlur stdDeviation="3.5" result="coloredBlur"/>
                <feMerge>
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                </feMerge>
            </filter>
        </defs>
        <g transform="translate(5 10)" opacity="0.8" filter="url(#glow-purple)">
            <ellipse cx="45" cy="65" rx="28" ry="18" stroke="#C4B5FD" strokeWidth="2" fill="none"/>
            <ellipse cx="68" cy="55" rx="18" ry="15" stroke="#C4B5FD" strokeWidth="2" fill="none"/>
            <ellipse cx="25" cy="55" rx="20" ry="16" stroke="#C4B5FD" strokeWidth="2" fill="none"/>
            <ellipse cx="45" cy="40" rx="25" ry="18" stroke="#C4B5FD" strokeWidth="2" fill="none"/>
            <g transform="translate(50 35)">
                <ellipse cx="0" cy="0" rx="16" ry="18" stroke="#C4B5FD" strokeWidth="2" fill="none"/>
                <circle cx="-6" cy="2" r="2" fill="#F5F3FF"/>
                <circle cx="6" cy="2" r="2" fill="#F5F3FF"/>
            </g>
        </g>
    </svg>
);

export const CrystalFishIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <defs>
            <linearGradient id="crystal-gradient" x1="50" y1="10" x2="50" y2="90" gradientUnits="userSpaceOnUse">
                <stop stopColor="#A5F3FC"/>
                <stop offset="1" stopColor="#0891B2"/>
            </linearGradient>
            <linearGradient id="crystal-highlight" x1="50" y1="10" x2="50" y2="90" gradientUnits="userSpaceOnUse">
                <stop stopColor="white" stopOpacity="0.9"/>
                <stop offset="1" stopColor="white" stopOpacity="0"/>
            </linearGradient>
        </defs>
        <path d="M90 50C90 72.0914 72.0914 90 50 90C27.9086 90 10 72.0914 10 50C10 38.9329 15.0366 29.0142 22.901 22.0988L50 10L77.099 22.0988C84.9634 29.0142 90 38.9329 90 50Z" fill="url(#crystal-gradient)" opacity="0.8"/>
        <path d="M50 10L22.901 22.0988 L50 90 L77.099 22.0988 L50 10Z" stroke="white" strokeOpacity="0.3" />
        <path d="M50 10L77.099 22.0988C84.9634 29.0142 90 38.9329 90 50C90 55 88.5 60 86 64" stroke="url(#crystal-highlight)" strokeWidth="2"/>
    </svg>
);

export const BellflowerIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
         <defs>
            <linearGradient id="bell-gradient" x1="50" y1="20" x2="50" y2="80" gradientUnits="userSpaceOnUse">
                <stop stopColor="#A5B4FC"/>
                <stop offset="1" stopColor="#6366F1"/>
            </linearGradient>
        </defs>
        <path d="M50 90V40" stroke="#BFDBFE" strokeWidth="3" strokeLinecap="round"/>
        <path d="M30 40 C 30 60, 70 60, 70 40 L 50 20 Z" fill="url(#bell-gradient)" />
        <ellipse cx="50" cy="40" rx="22" ry="5" fill="none" stroke="#818CF8" strokeWidth="2"/>
    </svg>
);

export const MorningDewIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <defs>
            <radialGradient id="dew-gradient" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(65 35) rotate(90) scale(50)">
                <stop stopColor="#D1FAE5" />
                <stop offset="1" stopColor="#34D399" stopOpacity="0.7"/>
            </radialGradient>
        </defs>
        <circle cx="50" cy="50" r="40" fill="url(#dew-gradient)" opacity="0.8"/>
        <path d="M45 55 L 50 60 L 55 55" stroke="#10B981" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M50 60 V 45 C 50 40, 60 40, 60 45" stroke="#10B981" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M35 35C40 30 50 32 55 40" stroke="white" strokeWidth="4" strokeLinecap="round" opacity="0.8"/>
    </svg>
);

// New Theme Icons
export const AuroraIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M3 6c6-3 12 3 18 0" stroke="#34D399"/>
      <path d="M3 12c6-3 12 3 18 0" stroke="#A78BFA"/>
      <path d="M3 18c6-3 12 3 18 0" stroke="#F472B6"/>
    </svg>
);
export const ForestIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => <LeafIcon className={className} {...props} />;
export const DeepSeaIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M12 12m-8 0a8 8 0 1 0 16 0a8 8 0 1 0 -16 0" />
      <path d="M12 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" />
      <path d="M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
    </svg>
);

// --- New Decoration Icons ---
export const GlowingTreeIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
  <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 13l-2 -2" /><path d="M12 12l2 -2" /><path d="M12 21v-13" /><path d="M9.824 15.995a3 3 0 0 1 -2.743 -3.585l.519 -3.415a3 3 0 0 1 4.352 -2.311l3.515 1.406a3 3 0 0 1 1.957 3.843l-1.994 4.197a3 3 0 0 1 -3.843 1.957l-1.406 -.352z" /></svg>
);
export const CrystalTowerIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
  <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 3l4 4l-4 4l-4 -4z" /><path d="M12 21v-10" /><path d="M8 11l-4 4l8 8l8 -8l-4 -4" /></svg>
);
export const SleepingFoxIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
  <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M14 3l-1.146 1.146a1 1 0 0 1 -1.707 .001l-1.147 -1.147" /><path d="M4 12c0 -2.667 2.667 -4 4 -4c.667 0 1.333 .167 2 .5c.667 -.333 1.333 -.5 2 -.5c1.333 0 4 1.333 4 4c0 1.536 -1.115 2.802 -2.71 3.23" /><path d="M8 12v-.5" /><path d="M5 18c2.667 0 5.333 -1.667 8 -5" /><path d="M11.054 12.318c.28 -1.22 1.23 -2.203 2.446 -2.318" /></svg>
);
export const DreamWhaleIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <defs><linearGradient id="whaleGrad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stopColor="#a78bfa"/><stop offset="100%" stopColor="#34d399"/></linearGradient><filter id="whaleGlow"><feGaussianBlur stdDeviation="2.5" result="coloredBlur"/><feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>
        <path d="M14.5 32c-5-5-5-15 0-20 6-5 18 0 26 8s12 20 2 26c-8 5-22 3-28-4z" fill="url(#whaleGrad)" opacity="0.7" filter="url(#whaleGlow)"/><path d="M45 40s-8 8-18 4-12-12-4-18" stroke="white" strokeWidth="1.5" strokeLinecap="round"/><circle cx="24" cy="24" r="1.5" fill="white"/>
    </svg>
);
export const StarflowerIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 17.75l-6.172 3.245l1.179-6.873l-5-4.867l6.9-1l3.086-6.253l3.086 6.253l6.9 1l-5 4.867l1.179 6.873z" /></svg>
);
export const RainbowGeyserIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M8 18l-3 -3" /><path d="M11 21l-3 -3" /><path d="M14 18l-3 -3" /><path d="M8 12l3-3a1 1 0 0 1 1.414 0l3 3" /><path d="M14.418 13.582a1 1 0 0 1 -1.414 0l-3-3" /></svg>
);
export const JellyAuroraIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M3 17c3 -2 6 2 9 0s6 -2 9 0" stroke="#f472b6" /><path d="M3 14c3 -2 6 2 9 0s6 -2 9 0" stroke="#a78bfa"/><path d="M3 11c3 -2 6 2 9 0s6 -2 9 0" stroke="#34d399"/></svg>
);
export const GlimmerSpritesIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /><path d="M5.636 5.636m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /><path d="M18.364 5.636m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /></svg>
);
export const StardustWaterfallIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M10 20a1 1 0 0 1 -1 1h-2a1 1 0 0 1 -1 -1v-8a1 1 0 0 1 1 -1h2a1 1 0 0 1 1 1v8z" /><path d="M14 20a1 1 0 0 1 -1 1h-2a1 1 0 0 1 -1 -1v-10a1 1 0 0 1 1 -1h2a1 1 0 0 1 1 1v10z" /><path d="M18 20a1 1 0 0 1 -1 1h-2a1 1 0 0 1 -1 -1v-5a1 1 0 0 1 1 -1h2a1 1 0 0 1 1 1v5z" /><path d="M15 5l-2 -2" /><path d="M12 3l-2 2" /><path d="M9 5l-2 -2" /></svg>
);
export const WhisperingChimeIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M6 3h12" /><path d="M6 12h12" /><path d="M6 21h12" /><path d="M10.333 3v18" /><path d="M14.667 3v18" /></svg>
);
export const LuminousJellyTentIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M11 14l4 6h-8l4 -6" /><path d="M12 4c-4.418 0 -8 3.582 -8 8s3.582 8 8 8s8 -3.582 8 -8s-3.582 -8 -8 -8" /><path d="M12 4v-1" /><path d="M12 21v-1" /><path d="M4 12h-1" /><path d="M21 12h-1" /></svg>
);
export const MilkyWayPathIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M3.293 16.707l5.414 -5.414a2 2 0 0 1 2.828 0l3.172 3.172a2 2 0 0 0 2.828 0l2.172 -2.172" /><path d="M10 5.5l-5 5" /><path d="M16 8l-3 3" /><path d="M19 11l-.5 .5" /></svg>
);
export const FloatingCrystalIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 5h6l4 5l-8 10l-8 -10z" /><path d="M12 20l0 -15" /><path d="M5 10h14" /></svg>
);
export const CloudSheepIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M18.5 16a2.5 2.5 0 1 0 0 -5h-12.5a4.5 4.5 0 0 0 0 9h12.5a2.5 2.5 0 0 0 0 -5z" /><path d="M10 11a2.5 2.5 0 1 0 0 -5a2.5 2.5 0 0 0 0 5z" /><path d="M12.5 11h-2.5a2 2 0 0 0 -2 2v1" /><path d="M14 14v.01" /><path d="M10 14v.01" /></svg>
);
export const BubbleLampIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 12m-8 0a8 8 0 1 0 16 0a8 8 0 1 0 -16 0" /><path d="M12 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" /><path d="M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /></svg>
);
export const CosmicJellyfishIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 3c-5.908 1.429 -11 5.998 -11 12v2h16v-2c0 -6.002 -5.092 -10.571 -11 -12" /><path d="M5 17c0 .552 .448 1 1 1s1 -.448 1 -1" /><path d="M11 17c0 .552 .448 1 1 1s1 -.448 1 -1" /><path d="M17 17c0 .552 .448 1 1 1s1 -.448 1 -1" /></svg>
);


// Sticker Icons
export const StarIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" {...props}><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
);

export const MoonIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" {...props}><path d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.64-.11 2.41-.31-3.12-.91-5.41-3.93-5.41-7.42 0-4.49 3.58-8.1 8-8.1.18 0 .35 0 .53.02-1.24-1.92-3.3-3.19-5.53-3.19z"/></svg>
);

export const CloudIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" {...props}><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z"/></svg>
);

export const HeartIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" {...props}><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
);

export const MusicIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" {...props}><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg>
);

export const CatIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
  <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M16 22l-4-4" /><path d="M12 18l-4 4" /><path d="M12 18l4 4" /><path d="M12 18l-4-4" /><path d="M20.5 10.5c.3 .3 .5 .7 .5 1.2c0 .5 -.2 .9 -.5 1.2c-.3 .3 -.7 .5 -1.2 .5c-.5 0 -.9 -.2 -1.2 -.5c-.3 -.3 -.5 -.7 -.5 -1.2c0 -.5 .2 -.9 .5 -1.2c.3 -.3 .7 -.5 1.2 -.5c.5 0 .9 .2 1.2 .5" /><path d="M3.5 10.5c.3 .3 .5 .7 .5 1.2c0 .5 -.2 .9 -.5 1.2c-.3 .3 -.7 .5 -1.2 .5c-.5 0 -.9 -.2 -1.2 -.5c-.3 -.3 -.5 -.7 -.5 -1.2c0 -.5 .2 -.9 .5 -1.2c.3 -.3 .7 -.5 1.2 -.5c.5 0 .9 .2 1.2 .5" /><path d="M15.5 4a3.5 3.5 0 0 0 -3.5 3.5v.5h-4v-.5a3.5 3.5 0 0 0 -7 0v8.5a3.5 3.5 0 0 0 3.5 3.5h11a3.5 3.5 0 0 0 3.5 -3.5v-8.5a3.5 3.5 0 0 0 -3.5 -3.5" /></svg>
);

export const LeafIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
  <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 21c.5 -4.5 2.5 -8 7 -10" /><path d="M9 18c6.218 0 10.5 -3.288 11 -12v-2h-4.014c-9 0 -11.986 4 -12 9c0 1 0 3 2 5h3z" /></svg>
);

export const SunIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" {...props}><path d="M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zM2 13h2c.55 0 1-.45 1-1s-.45-1-1-1H2c-.55 0-1 .45-1 1s.45 1 1 1zm18 0h2c.55 0 1-.45 1-1s-.45-1-1-1h-2c-.55 0-1 .45-1 1s.45 1 1 1zm-9-8V3c0-.55-.45-1-1-1s-1 .45-1 1v2c0 .55.45 1 1 1s1-.45 1-1zm0 14v-2c0-.55-.45-1-1-1s-1 .45-1 1v2c0 .55.45 1 1 1s1-.45 1-1zM5.64 6.36c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41l1.06 1.06c.39.39 1.02.39 1.41 0s.39-1.02 0-1.41L5.64 6.36zm12.73 12.73c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41l1.06 1.06c.39.39 1.02.39 1.41 0 .39-.39.39-1.02 0-1.41l-1.06-1.06zM5.64 17.64l-1.06 1.06c-.39.39-.39 1.02 0 1.41s1.02.39 1.41 0l1.06-1.06c.39-.39.39-1.02 0-1.41s-1.02-.39-1.41 0zM18.36 5.64c.39-.39.39-1.02 0-1.41s-1.02-.39-1.41 0l-1.06 1.06c-.39.39-.39 1.02 0 1.41s1.02.39 1.41 0l1.06-1.06z"/></svg>
);

export const PlanetIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M18.816 13.58c2.292 2.138 3.54 5.42 2.184 8.42" /><path d="M18 11a7 7 0 1 0 -10.323 5.89" /><path d="M12.33 14.695c-2.464 -2.48 -2.25 -7.02 .013 -9.685" /></svg>
);

export const FeatherIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 20l10 -10" /><path d="M10 20l4 -4" /><path d="M6 16l4 -4" /><path d="M8 12l4 -4" /><path d="M10 8l4 -4" /><path d="M12 20v.01" /><path d="M8 16v.01" /><path d="M4 12v.01" /><path d="M4 4h4" /><path d="M20 4h-4" /></svg>
);

export const KeyIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M16.555 3.843l3.602 3.602a2.877 2.877 0 0 1 0 4.069l-2.643 2.643a2.877 2.877 0 0 1 -4.069 0l-.301 -.301l-6.558 6.558a2 2 0 0 1 -1.239 .578l-.175 .008h-1.172a1 1 0 0 1 -.993 -.883l-.007 -.117v-1.172a2 2 0 0 1 .467 -1.284l.119 -.13l.414 -.414h2v-2h2v-2l2.121 -2.121l.301 -.301a2.877 2.877 0 0 1 4.069 0z" /><path d="M15 9h.01" /></svg>
);

export const LanternIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 4h6a3 3 0 0 1 3 3v2" /><path d="M12 11l0 9" /><path d="M8 20h8" /><path d="M9 14h6" /><path d="M11 4v-2h2v2" /><path d="M6 6.284a3 3 0 0 1 2.995 -2.284l.005 -.001h.005" /></svg>
);

export const PaperPlaneIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 10l-4 4l6 6l4 -16l-18 7l4 2l2 6l3 -4" /></svg>
);

export const OrigamiBirdIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 12l-8 -8l9 0l8 8l-9 0" /><path d="M12.5 11.5l-3.5 3.5" /><path d="M14 15.5l5.5 -5.5" /><path d="M12 12l0 9.5" /><path d="M12 12l-1.5 -1.5" /></svg>
);

export const BookIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M3 19a9 9 0 0 1 9 0a9 9 0 0 1 9 0" /><path d="M3 6a9 9 0 0 1 9 0a9 9 0 0 1 9 0" /><path d="M3 6l0 13" /><path d="M12 6l0 13" /><path d="M21 6l0 13" /></svg>
);

export const TeaCupIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 11h14v-3h-14z" /><path d="M17.5 11l-1.5 10h-8l-1.5 -10" /><path d="M6 8v-1a2 2 0 0 1 2 -2h8a2 2 0 0 1 2 2v1" /><path d="M15 5v-2" /></svg>
);

export const LockedIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-16 h-16', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 11m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /><path d="M10 11v-4a2 2 0 1 1 4 0v4" /><path d="M4 4m0 2a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2z" /></svg>
);

// Dream Fragment Icons
export const GlowingDeerIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-12 h-12', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 3l-1.5 2.5" /><path d="M15 3l-1.5 2.5" /><path d="M9 3l1.5 2.5" /><path d="M18 3l1.5 2.5" /><path d="M6 3l-1.5 2.5" /><path d="M3 8c1.333 -2.667 3.333 -4 6 -4" /><path d="M21 8c-1.333 -2.667 -3.333 -4 -6 -4" /><path d="M12 14v-11" /><path d="M6.5 10c-1.5 2.5 -1.5 6.5 0 8" /><path d="M17.5 10c1.5 2.5 1.5 6.5 0 8" /><path d="M12 21c-2.667 -2.667 -4 -5.333 -4 -8" /><path d="M12 21c2.667 -2.667 4 -5.333 4 -8" /><path d="M12 14a2 2 0 1 0 0 -4a2 2 0 0 0 0 4z" /></svg>
);
export const StarlightFishIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-12 h-12', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M13.435 18.026c-1.84 .936 -3.882 1.25 -5.894 .789c-4.426 -1.018 -7.387 -5.105 -6.369 -9.53c1.018 -4.426 5.105 -7.387 9.53 -6.369c4.426 1.018 7.387 5.105 6.369 9.53c-.34 1.472 -.967 2.827 -1.823 4.01" /><path d="M10 8v.01" /><path d="M14 11v.01" /><path d="M17 14v.01" /><path d="M20 17v.01" /></svg>
);
export const RainbowCloudIcon: React.FC<React.SVGProps<SVGSVGElement>> = ({ className = 'w-12 h-12', ...props }) => (
    <svg className={className} viewBox="0 0 24 24" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M3 17c3 -2 6 2 9 0s6 -2 9 0" stroke="#f472b6" /><path d="M3 14c3 -2 6 2 9 0s6 -2 9 0" stroke="#a78bfa"/><path d="M3 11c3 -2 6 2 9 0s6 -2 9 0" stroke="#34d399"/></svg>
);