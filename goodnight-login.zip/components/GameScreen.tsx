import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import type { GameTheme, AnimatingObject, GameState, SoundWave, Bubble, Settings, BlessingText, ShopItem, TranslationKey } from '../types';
import { WoodenMalletIcon, HeartIcon, StarIcon, MoonIcon, FeatherIcon, LanternIcon, OrigamiBirdIcon, MusicIcon } from './icons/ThemeIcons';
import { useTranslations, SHOP_ITEMS, CONSTELLATION_WORDS, DREAM_FRAGMENTS } from '../constants';
import Card from './common/Card';

interface HaloEffect {
  id: number;
  x: number;
  y: number;
}

// --- New Game-Specific Types ---
interface RiverMoon {
  id: number;
  x: number;
  y: number;
  size: number;
  opacity: number;
  vy: number; // Vertical velocity
  ay: number; // Vertical acceleration (gravity)
  baseY: number; // The Y it returns to
  isSuperJumping?: boolean;
  superJumpTimer?: number;
  color: string;
}

interface Ripple {
  id: number;
  x: number;
  y: number;
  age: number; // 0 to 1
  color: string;
}

const GRASS_PATHS = [
  "M50 100 C 40 80, 40 60, 50 50 S 60 20, 50 0",
  "M50 100 C 55 80, 60 60, 50 50 S 45 20, 50 0",
  "M50 100 C 45 70, 55 70, 50 50 S 48 25, 50 0",
  "M50 100 C 50 80, 40 70, 50 50 S 60 30, 50 0",
  "M50 100 C 60 85, 60 65, 50 50 S 40 15, 50 0",
];

interface GardenPlant {
  id: number;
  x: number;
  y: number;
  size: number;
  rotation: number;
  creationTime: number;
  path: string;
}

interface CloudFragment {
    id: string;
    x: number;
    y: number;
    icon: React.FC<React.SVGProps<SVGSVGElement>>;
}

interface CloudParticle {
    id: number;
    x: number;
    y: number;
    vx: number;
    vy: number;
    opacity: number;
    size: number;
}


interface GameScreenProps {
  theme: GameTheme;
  activeSkinId?: string;
  onGameEnd: (session: Omit<GameState, 'date' | 'isWishFulfilled'>) => void;
  settings: Settings;
}

const BLESSING_OPTIONS_ZH = ['功德+1', '事业+1', '财富+1', '爱情+1', '健康+1', '快乐+1', '智慧+1'];
const BLESSING_OPTIONS_EN = ['Karma+1', 'Career+1', 'Wealth+1', 'Love+1', 'Health+1', 'Joy+1', 'Wisdom+1'];

const ALL_POSSIBLE_FRAGMENTS = [
    ...DREAM_FRAGMENTS,
    { id: 'star', icon: StarIcon },
    { id: 'moon', icon: MoonIcon },
    { id: 'heart', icon: HeartIcon },
    { id: 'music', icon: MusicIcon },
    { id: 'feather', icon: FeatherIcon },
    { id: 'lantern', icon: LanternIcon },
    { id: 'origami', icon: OrigamiBirdIcon },
];

const getRandomMoonColor = () => {
    const rand = Math.random();
    if (rand < 0.6) { // 60% chance for cool tones
        return `hsl(${200 + Math.random() * 40}, 95%, 90%)`; // Brighter, more saturated blues/cyans
    } else if (rand < 0.9) { // 30% chance for warm tones
        return `hsl(${40 + Math.random() * 20}, 100%, 92%)`; // Bright, saturated yellows/golds
    } else { // 10% chance for pure white
        return `hsl(0, 0%, 98%)`;
    }
};

const GameScreen: React.FC<GameScreenProps> = ({ theme, activeSkinId, onGameEnd, settings }) => {
  const [clicks, setClicks] = useState(0);
  const [startTime] = useState(Date.now());
  const [animatingObjects, setAnimatingObjects] = useState<AnimatingObject[]>([]);
  const [stars, setStars] = useState<{ id: number; x: number; y: number; delay: number, size: number, opacity: number }[]>([]);
  const [haloEffects, setHaloEffects] = useState<HaloEffect[]>([]);
  const [soundWaves, setSoundWaves] = useState<SoundWave[]>([]);
  const [bubbles, setBubbles] = useState<Bubble[]>([]);
  const [blessingTexts, setBlessingTexts] = useState<BlessingText[]>([]);
  const [isMalletAnimating, setIsMalletAnimating] = useState(false);
  
  // --- NEW GAME STATES ---
  const [constellationInfo, setConstellationInfo] = useState<{ name: string; description: string } | null>(null);
  const [isNaming, setIsNaming] = useState(false);
  const [riverMoons, setRiverMoons] = useState<RiverMoon[]>([]);
  const [ripples, setRipples] = useState<Ripple[]>([]);
  const [cloudFragments, setCloudFragments] = useState<CloudFragment[]>([]);
  const [cloudParticles, setCloudParticles] = useState<CloudParticle[]>([]);
  const [discoveredFragments, setDiscoveredFragments] = useState<Set<string>>(new Set());
  const [isDiscoveryRoundOver, setIsDiscoveryRoundOver] = useState(false);
  const maskCanvasRef = useRef<HTMLCanvasElement>(null);
  const [gardenPlants, setGardenPlants] = useState<GardenPlant[]>([]);
  const [isLeafShowerActive, setIsLeafShowerActive] = useState(false);

  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isDrawing = useRef(false);
  const lastDrawPoint = useRef<{x:number, y:number} | null>(null);
  const drawnPath = useRef<{x:number, y:number}[]>([]);
  const connectedStars = useRef<Set<number>>(new Set());


  const nextId = useRef(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const inactivityTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const t = useTranslations(settings.language);
  const isEnding = useRef(false);

  const activeItem: ShopItem = useMemo(() => {
    return SHOP_ITEMS.find(item => item.id === activeSkinId) || theme;
  }, [activeSkinId, theme]);

  const handleEndSession = useCallback(() => {
    if (isEnding.current) return;
    isEnding.current = true;
    
    if (inactivityTimer.current) {
      clearTimeout(inactivityTimer.current);
    }
    const duration = Math.round((Date.now() - startTime) / 1000);
    // For discovery game, "clicks" is number of found fragments
    const finalClicks = theme.gameType === 'discovery' ? discoveredFragments.size : clicks;
    onGameEnd({ themeId: theme.id, clicks: finalClicks, duration });
  }, [clicks, onGameEnd, startTime, theme, discoveredFragments]);

  const resetInactivityTimer = useCallback(() => {
    if (inactivityTimer.current) {
      clearTimeout(inactivityTimer.current);
    }
    inactivityTimer.current = setTimeout(handleEndSession, 20 * 1000); // 20 seconds
  }, [handleEndSession]);

  useEffect(() => {
    resetInactivityTimer();
    return () => {
      if (inactivityTimer.current) {
        clearTimeout(inactivityTimer.current);
      }
    };
  }, [resetInactivityTimer]);

  const createBubble = useCallback((options: Partial<Bubble> = {}): Bubble => {
      const rand = Math.random();
      let type: Bubble['type'];
      let color: string;

      const incomingType = options.type;

      if (!incomingType) {
        if (rand < 0.15) { // 15% chance for heart
            type = 'heart';
            color = `hsl(330, 90%, 80%)`;
        } else if (rand < 0.40) { // 25% chance for splitter
            type = 'splitter';
            color = `hsl(50, 90%, 80%)`;
        } else { // 60% chance for normal
            type = 'normal';
            color = `hsl(${Math.random() * 360}, 70%, 80%)`;
        }
      } else {
        type = incomingType;
        color = options.color || `hsl(${Math.random() * 360}, 70%, 80%)`;
      }
      
      return {
          id: nextId.current++,
          x: options.x ?? Math.random() * 100,
          y: options.y ?? 110, // Start off-screen at the bottom
          vx: (Math.random() - 0.5) * 0.1,
          vy: -0.1 - Math.random() * 0.15,
          size: options.size ?? 30 + Math.random() * 40,
          color,
          opacity: 0.3 + Math.random() * 0.4,
          type,
          ...options,
      };
  }, []);

  // --- LOCAL CONSTELLATION NAMING ---
  const generateLocalConstellationName = (
    starCount: number, 
    isClosed: boolean, 
    aspectRatio: number
  ): { name: string; description: string } => {
    const lang = settings.language;
    const words = CONSTELLATION_WORDS[lang];
    const getRandom = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];
    
    const adjective = getRandom(words.adjectives);
    let noun: string;

    const canvasArea = canvasRef.current ? canvasRef.current.width * canvasRef.current.height : 1;
    const pathBbox = drawnPath.current.reduce((acc, p) => ({
      minX: Math.min(acc.minX, p.x),
      maxX: Math.max(acc.maxX, p.x),
      minY: Math.min(acc.minY, p.y),
      maxY: Math.max(acc.maxY, p.y),
    }), { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity });
    const pathArea = (pathBbox.maxX - pathBbox.minX) * (pathBbox.maxY - pathBbox.minY);

    if (starCount > 7 && (pathArea / canvasArea < 0.1)) {
        noun = getRandom(words.nounsCluster);
    } else if (isClosed) {
        noun = getRandom(words.nounsClosed);
    } else {
        noun = getRandom(words.nounsOpen);
    }

    const name = lang === 'en' ? `${adjective} ${noun}` : `${adjective}${noun}`;
    const descKey = `desc-${theme.id}` as TranslationKey;
    const description = t(descKey);
    return { name, description };
  };

  const resetCloudGame = useCallback(() => {
    setIsDiscoveryRoundOver(false);
    setDiscoveredFragments(new Set());

    const numFragments = Math.floor(Math.random() * 8) + 3; // 3 to 10
    const selectedFragments = ALL_POSSIBLE_FRAGMENTS.sort(() => 0.5 - Math.random())
        .slice(0, numFragments)
        .map(frag => ({
            ...frag,
            x: 15 + Math.random() * 70,
            y: 20 + Math.random() * 60,
        }));
    setCloudFragments(selectedFragments);
    
    const canvas = maskCanvasRef.current;
    if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
            canvas.width = canvas.offsetWidth;
            canvas.height = canvas.offsetHeight;
            const gradient = ctx.createRadialGradient(canvas.width/2, canvas.height/2, 100, canvas.width/2, canvas.height/2, Math.max(canvas.width, canvas.height)/2);
            gradient.addColorStop(0, "rgba(230, 230, 240, 1)");
            gradient.addColorStop(1, "rgba(200, 200, 220, 1)");
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
    }
  }, []);

  // --- INITIALIZATION ---
  useEffect(() => {
    let starCount = 20;
    if (theme.gameType === 'drawing') starCount = 80;
    if (theme.gameType === 'fluid') starCount = 30;
    
    const initialStars = Array.from({ length: starCount }, (_, i) => ({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        delay: Math.random() * 5,
        size: Math.random() * 1.5 + 0.5,
        opacity: 0.5 + Math.random() * 0.5
    }));
    setStars(initialStars);

    if (theme.gameType === 'popper') {
        const initialBubbles = Array.from({ length: 15 }, () => createBubble());
        setBubbles(initialBubbles);
    } else if (theme.gameType === 'fluid') {
        const initialMoons = Array.from({ length: 35 }, (_, i) => {
            const baseY = 40 + Math.random() * 40;
            return {
                id: i,
                x: Math.random() * 100,
                y: baseY,
                size: 30 + Math.random() * 40,
                opacity: 0.6 + Math.random() * 0.4,
                vy: 0,
                ay: 0.02,
                baseY,
                color: getRandomMoonColor(),
            }
        });
        setRiverMoons(initialMoons);
    } else if (theme.gameType === 'discovery') {
        resetCloudGame();
    }
  }, [theme.gameType, createBubble, resetCloudGame]);

    // Game reset logic for discovery game
    useEffect(() => {
        if (theme.gameType === 'discovery' && cloudFragments.length > 0 && discoveredFragments.size === cloudFragments.length && !isDiscoveryRoundOver) {
            setIsDiscoveryRoundOver(true);
        }
    }, [theme.gameType, discoveredFragments.size, cloudFragments.length, isDiscoveryRoundOver]);

   // Pity timer for discovery game
  useEffect(() => {
    if (theme.gameType !== 'discovery') return;
    const timer = setInterval(() => {
        if (discoveredFragments.size < cloudFragments.length) {
            // This is a placeholder for revealing a hint
        }
    }, 30000);
    return () => clearInterval(timer);
  }, [theme.gameType, discoveredFragments.size, cloudFragments.length]);

  // --- AUDIO & HAPTICS ---
  useEffect(() => {
    if (theme.audioSrc) {
        audioRef.current = new Audio(theme.audioSrc);
        audioRef.current.volume = 0.6;
    }
  }, [theme.audioSrc]);

  const playSound = useCallback(() => {
    if (settings.sfx && audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(e => console.error("Audio play failed:", e));
    }
  }, [settings.sfx]);

  const playVibration = useCallback((pattern: VibratePattern) => {
    if (settings.sfx && 'vibrate' in navigator) {
        try {
            navigator.vibrate(pattern);
        } catch (e) {
            console.warn("Haptic feedback failed:", e);
        }
    }
  }, [settings.sfx]);

  // --- OBJECT CREATION ---
  const createObject = useCallback(() => {
    const newObject: AnimatingObject = {
      id: nextId.current++,
      x: 45 + Math.random() * 10,
      y: 50,
      vx: (Math.random() - 0.5) * 0.4,
      rotation: (Math.random() - 0.5) * 20,
      scale: 1,
      opacity: 1,
    };
    setAnimatingObjects((prev) => [...prev, newObject]);
  }, []);

  const createSoundWave = useCallback(() => {
    const newWave: SoundWave = { id: nextId.current++ };
    setSoundWaves(prev => [...prev, newWave]);
    setTimeout(() => setSoundWaves(prev => prev.filter(sw => sw.id !== newWave.id)), 2000);
  }, []);

  const createBlessingText = useCallback(() => {
    const blessingOptions = settings.language === 'zh' ? BLESSING_OPTIONS_ZH : BLESSING_OPTIONS_EN;
    const newBlessing: BlessingText = {
        id: nextId.current++,
        text: blessingOptions[Math.floor(Math.random() * blessingOptions.length)],
        x: 40 + Math.random() * 20, 
        y: 30 + Math.random() * 20,
    };
    setBlessingTexts(prev => [...prev, newBlessing]);
    setTimeout(() => setBlessingTexts(prev => prev.filter(b => b.id !== newBlessing.id)), 1500);
  }, [settings.language]);


  const handleInteraction = () => {
    setClicks(c => c + 1);
    playSound();
    resetInactivityTimer();
    
    switch(theme.gameType) {
        case 'tap-generator':
            playVibration(100);
            createSoundWave();
            createBlessingText();
            if (!isMalletAnimating) {
                setIsMalletAnimating(true);
                setTimeout(() => setIsMalletAnimating(false), 300);
            }
            break;
        case 'count-generator':
        case 'blow-generator':
            playVibration(50);
            createObject();
            break;
        case 'generative':
            // Handled by on-canvas click
            break;
        default:
            break;
    }
  };
  
  // --- ANIMATION LOOPS ---
  useEffect(() => {
    const interval = setInterval(() => {
      setAnimatingObjects(currentObjects => 
        currentObjects
          .map(obj => {
            let y = obj.y, x = obj.x, rotation = obj.rotation, scale = obj.scale, opacity = obj.opacity, vx = obj.vx;
            if (obj.icon) { y -= 0.8; opacity *= 0.985; scale *= 0.99; } 
            else {
                y -= 0.4; x += vx; rotation += (Math.random() - 0.5) * 0.1;
                if (theme.gameType === 'blow-generator') { y -= 0.2; vx += (Math.random() - 0.5) * 0.05; scale *= 0.995; opacity *= 0.99; } 
                else if(theme.gameType === 'count-generator') { rotation += (Math.random() - 0.5) * 0.2; }
            }
            return {...obj, y, x, vx, rotation, scale, opacity };
          })
          .filter(obj => {
            const isFaded = obj.opacity < 0.05;
            if (obj.icon) return !isFaded && obj.y > -10;
            const isOffScreen = obj.y < -10 || obj.x < -10 || obj.x > 110;
            if (isFaded || isOffScreen) {
              if (theme.gameType === 'count-generator') {
                  const endY = 20 + Math.random() * 40;
                  setStars(s => [...s, { id: obj.id, x: obj.x, y: endY, delay: Math.random() * 5, size: 2, opacity: 1 }]);
                  setHaloEffects(h => [...h, { id: obj.id, x: obj.x, y: endY }]);
              }
              return false;
            }
            return true;
          })
      );
      // Fluid game
      setRiverMoons(moons => {
        const riverSpeed = 0.05 + Math.sin(Date.now() / 3000) * 0.02;
        return moons.map(moon => {
            let { x, y, vy, ay, isSuperJumping, superJumpTimer, size, color, baseY } = moon;

            if (isSuperJumping) {
                if (superJumpTimer! > 0) {
                    y += vy;
                    vy *= 0.98; // Slow down at the top
                    superJumpTimer = superJumpTimer! - 1;
                } else {
                    isSuperJumping = false;
                }
            } else {
                vy += ay;
                y += vy;
                if (y > moon.baseY) {
                    y = moon.baseY;
                    vy = 0;
                }
            }
            
            let newX = x + riverSpeed;
            if (newX > 105) { // When it goes off screen right (+ buffer)
                newX = -5; // Reset to off screen left
                baseY = 40 + Math.random() * 40;
                y = baseY; // Reset y position
                size = 30 + Math.random() * 40; // Reset size
                color = getRandomMoonColor();
                return { ...moon, x: newX, y, size, color, baseY, vy, isSuperJumping, superJumpTimer };
            }
            
            return { ...moon, x: newX, y, vy, isSuperJumping, superJumpTimer };
        });
      });
      setRipples(r => r.map(ripple => ({...ripple, age: ripple.age + 0.01})).filter(ripple => ripple.age <= 1));
      
      // Cloud particles
      setCloudParticles(particles => particles.map(p => ({
        ...p,
        x: p.x + p.vx,
        y: p.y + p.vy,
        opacity: p.opacity * 0.98,
        size: p.size * 0.99
      })).filter(p => p.opacity > 0.01));

    }, 16); // ~60fps

    return () => clearInterval(interval);
  }, [theme.gameType, ripples]);
  
  useEffect(() => {
    if (haloEffects.length > 0) {
      const timer = setTimeout(() => setHaloEffects(effects => effects.slice(1)), 700);
      return () => clearTimeout(timer);
    }
  }, [haloEffects]);

  useEffect(() => {
      if(theme.gameType !== 'popper') return;
      const interval = setInterval(() => {
        setBubbles(currentBubbles =>
            currentBubbles.map(b => {
                let newX = b.x + b.vx; let newY = b.y + b.vy;
                if(newX < (b.size/200)*100 || newX > 100-(b.size/200)*100) b.vx *= -1;
                if(newY < -10) { newY = 110; newX = Math.random() * 100; }
                return {...b, x: newX, y: newY};
            })
        )
      }, 16);
      return () => clearInterval(interval);
  }, [theme.gameType])


  // --- INTERACTION HANDLERS ---
  const handleBubblePop = (bubble: Bubble) => {
    setClicks(c => c + 1); playSound(); playVibration(30); resetInactivityTimer();
    setBubbles(prev => prev.filter(b => b.id !== bubble.id));
    if (bubble.type === 'splitter' && bubble.size > 20) {
        const newSize = bubble.size * 0.7;
        setBubbles(prev => [ ...prev,
            createBubble({ type: 'normal', x: bubble.x, y: bubble.y, size: newSize, vx: (bubble.vx + 0.1), vy: bubble.vy, color: bubble.color }),
            createBubble({ type: 'normal', x: bubble.x, y: bubble.y, size: newSize, vx: (bubble.vx - 0.1), vy: bubble.vy, color: bubble.color })
        ]);
    } else if (bubble.type === 'heart') {
        setAnimatingObjects(prev => [...prev, { id: nextId.current++, x: bubble.x, y: bubble.y, vx: 0, rotation: (Math.random() - 0.5) * 15, scale: bubble.size / 60, opacity: 1, icon: HeartIcon }]);
    }
    if (bubble.type !== 'splitter' || bubble.size <= 20) {
      setTimeout(() => setBubbles(prev => [...prev, createBubble()]), 500);
    }
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    resetInactivityTimer();
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    if (theme.gameType === 'fluid') {
        setClicks(c => c + 1); playSound(); playVibration(20);
        const newRipple: Ripple = { id: nextId.current++, x, y, age: 0, color: `hsl(${200 + Math.random() * 60}, 80%, 80%)` };
        setRipples(prev => [...prev, newRipple]);
        setRiverMoons(moons => moons.map(moon => {
            if (Math.hypot(moon.x - x, moon.y - y) < 8) {
                // Super jump logic
                if (Math.random() < 0.1) {
                    return { ...moon, vy: -1.2, isSuperJumping: true, superJumpTimer: 180 }; // 3 seconds at 60fps
                }
                return { ...moon, vy: -0.5 };
            }
            return moon;
        }));
    } else if (theme.gameType === 'generative') {
        setClicks(c => c + 1); playSound(); playVibration(20);
        if (gardenPlants.length > 30) {
            setGardenPlants(prev => prev.slice(1));
        }
        if (clicks > 0 && clicks % 29 === 0 && !isLeafShowerActive) {
             setIsLeafShowerActive(true);
             setTimeout(() => setIsLeafShowerActive(false), 5000);
        }
        const newPlant: GardenPlant = { id: nextId.current++, x, y, size: 20 + Math.random() * 30, rotation: Math.random() * 360, creationTime: Date.now(), path: GRASS_PATHS[Math.floor(Math.random() * GRASS_PATHS.length)] };
        setGardenPlants(prev => [...prev, newPlant]);
    }
  };

  const handleCloudReveal = (e: React.MouseEvent<HTMLDivElement>) => {
      const canvas = maskCanvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      ctx.globalCompositeOperation = 'destination-out';
      const gradient = ctx.createRadialGradient(x, y, 15, x, y, 40);
      gradient.addColorStop(0, 'rgba(0,0,0,0.4)');
      gradient.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(x, y, 40, 0, 2 * Math.PI);
      ctx.fill();

      // Particle effect
      for(let i=0; i<3; i++){
          const newParticle: CloudParticle = {
              id: nextId.current++,
              x, y,
              vx: (Math.random() - 0.5) * 2,
              vy: (Math.random() - 0.5) * 2,
              opacity: 1,
              size: Math.random() * 5 + 2
          }
          setCloudParticles(p => [...p, newParticle]);
      }

      cloudFragments.forEach(frag => {
          if (discoveredFragments.has(frag.id)) return;
          const fragX = (frag.x / 100) * rect.width;
          const fragY = (frag.y / 100) * rect.height;
          if (Math.hypot(x - fragX, y - fragY) < 30) {
              setDiscoveredFragments(prev => new Set(prev).add(frag.id));
              playSound(); playVibration(50);
          }
      });
  };

  // --- DRAWING LOGIC ---
  useEffect(() => {
    if (theme.gameType !== 'drawing') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    
    const getCoords = (e: MouseEvent | TouchEvent) => {
        const rect = canvas.getBoundingClientRect();
        const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
        const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
        return { x: clientX - rect.left, y: clientY - rect.top };
    };

    const draw = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        const currentPoint = lastDrawPoint.current;
        // Draw stars and check for pulsing
        stars.forEach(star => {
            const starX = (star.x / 100) * canvas.width;
            const starY = (star.y / 100) * canvas.height;
            const dist = currentPoint ? Math.hypot(currentPoint.x - starX, currentPoint.y - starY) : Infinity;
            
            ctx.beginPath();
            let radius = connectedStars.current.has(star.id) ? 4 : 2;
            let starOpacity = star.opacity;
            if (isDrawing.current && dist < 50) {
                radius *= 1.5;
                starOpacity = 1;
            }
            
            ctx.arc(starX, starY, radius, 0, 2 * Math.PI);
            ctx.fillStyle = connectedStars.current.has(star.id) ? `rgba(251, 191, 36, ${starOpacity})` : `rgba(255, 255, 255, ${starOpacity})`;
            ctx.fill();
        });

        // Draw finished path
        if (drawnPath.current.length > 1) {
            ctx.beginPath();
            ctx.moveTo(drawnPath.current[0].x, drawnPath.current[0].y);
            for (let i = 1; i < drawnPath.current.length; i++) {
                ctx.lineTo(drawnPath.current[i].x, drawnPath.current[i].y);
            }
            ctx.strokeStyle = '#FBBF24';
            ctx.lineWidth = 3;
            ctx.shadowColor = '#FBBF24';
            ctx.shadowBlur = 10;
            ctx.stroke();
            ctx.shadowBlur = 0; // Reset shadow
        }
    };

    const handleMouseDown = (e: MouseEvent | TouchEvent) => {
        e.preventDefault();
        isDrawing.current = true;
        drawnPath.current = [];
        connectedStars.current.clear();
        setConstellationInfo(null);
        lastDrawPoint.current = getCoords(e);
    };

    const handleMouseMove = (e: MouseEvent | TouchEvent) => {
        if (!isDrawing.current) return;
        e.preventDefault();
        const coords = getCoords(e);
        lastDrawPoint.current = coords;

        stars.forEach(star => {
            const starX = (star.x / 100) * canvas.width;
            const starY = (star.y / 100) * canvas.height;
            if (Math.hypot(coords.x - starX, coords.y - starY) < 20) {
                if (!connectedStars.current.has(star.id)) {
                    connectedStars.current.add(star.id);
                    drawnPath.current.push({ x: starX, y: starY });
                    setClicks(c => c + 1);
                    playVibration(20);
                }
            }
        });
        requestAnimationFrame(draw);
    };

    const handleMouseUp = (e: MouseEvent | TouchEvent) => {
        if (!isDrawing.current) return;
        e.preventDefault();
        isDrawing.current = false;
        lastDrawPoint.current = null;
        requestAnimationFrame(draw); // final draw
        resetInactivityTimer();

        if (connectedStars.current.size > 1) {
            setIsNaming(true);
            const path = drawnPath.current;
            const startPoint = path[0];
            const endPoint = path[path.length - 1];
            const isClosed = Math.hypot(endPoint.x - startPoint.x, endPoint.y - startPoint.y) < 30;

            const bbox = path.reduce((acc, p) => ({
                minX: Math.min(acc.minX, p.x), maxX: Math.max(acc.maxX, p.x),
                minY: Math.min(acc.minY, p.y), maxY: Math.max(acc.maxY, p.y),
            }), { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity });
            const width = bbox.maxX - bbox.minX;
            const height = bbox.maxY - bbox.minY;
            const aspectRatio = width / (height || 1);
            
            setTimeout(() => { // Simulate thinking
                const result = generateLocalConstellationName(connectedStars.current.size, isClosed, aspectRatio);
                setConstellationInfo(result);
                setIsNaming(false);
            }, 1500);
        } else {
             drawnPath.current = [];
             connectedStars.current.clear();
             requestAnimationFrame(draw);
        }
    };
    
    requestAnimationFrame(draw);

    canvas.addEventListener('mousedown', handleMouseDown);
    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mouseup', handleMouseUp);
    canvas.addEventListener('mouseleave', handleMouseUp);
    canvas.addEventListener('touchstart', handleMouseDown, { passive: false });
    canvas.addEventListener('touchmove', handleMouseMove, { passive: false });
    canvas.addEventListener('touchend', handleMouseUp);

    return () => {
        canvas.removeEventListener('mousedown', handleMouseDown);
        canvas.removeEventListener('mousemove', handleMouseMove);
        canvas.removeEventListener('mouseup', handleMouseUp);
        canvas.removeEventListener('mouseleave', handleMouseUp);
        canvas.removeEventListener('touchstart', handleMouseDown);
        canvas.removeEventListener('touchmove', handleMouseMove);
        canvas.removeEventListener('touchend', handleMouseUp);
    };
  }, [theme.gameType, stars, resetInactivityTimer, playVibration, settings.language, generateLocalConstellationName]);

  // --- RENDER LOGIC ---
  const renderCounter = () => {
    let count = clicks;
    if (theme.gameType === 'discovery') count = discoveredFragments.size;
    let label = t(theme.id as TranslationKey);
    if (theme.gameType === 'discovery') label = `${t(theme.id as TranslationKey)} (${discoveredFragments.size}/${cloudFragments.length})`;

    if (['drawing'].includes(theme.gameType)) { return null; }
    if (theme.id === 'secret-garden') label = t(theme.id as TranslationKey);

    return (
       <div className="absolute left-8 pointer-events-auto" style={{top: '100px'}}>
            <h2 className="text-lg text-white/80">{label}</h2>
            <p className="text-4xl font-bold tracking-widest text-white" style={{ textShadow: '0 0 10px rgba(255,255,255,0.5)' }}>{count}</p>
        </div>
    )
  }

  return (
    <div 
        className="w-full h-full flex flex-col items-center justify-center absolute inset-0 overflow-hidden"
        style={{ background: `linear-gradient(to bottom, ${theme.gradientFrom}, ${theme.gradientTo})` }}
    >
        {theme.gameType === 'fluid' && <div className="absolute inset-0 bg-black/30 z-0 pointer-events-none"></div>}
        {/* --- SHARED BACKGROUND ELEMENTS --- */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
            {stars.map(star => (
            <div key={star.id} className="absolute bg-white rounded-full animate-twinkle shadow-[0_0_10px_2px_rgba(255,255,255,0.7)]"
                style={{ left: `${star.x}%`, top: `${star.y}%`, width: `${star.size}px`, height: `${star.size}px`, transform: 'translate(-50%, -50%)', animationDelay: `${star.delay}s`, opacity: star.opacity }} />
            ))}
            {animatingObjects.map(obj => {
            const Icon = obj.icon || activeItem.icon; const iconColor = obj.icon ? 'text-pink-400' : activeItem.color; const iconSize = obj.icon ? 'w-8 h-8' : 'w-10 h-10'; const shadowColor = obj.icon ? 'rgba(244, 114, 182, 0.7)' : 'rgba(255,255,255,0.7)';
            return (
                <div key={obj.id} className="absolute" style={{ left: `${obj.x}%`, top: `${obj.y}%`, transform: `translate(-50%, -50%) scale(${obj.scale}) rotate(${obj.rotation}deg)`, opacity: obj.opacity, transition: 'opacity 0.5s, transform 0.5s' }}>
                    <div className={`${iconColor} opacity-80`} style={{ filter: `drop-shadow(0 0 8px ${shadowColor})` }}><Icon className={iconSize} /></div>
                </div>
            )})}
            {haloEffects.map(effect => (<div key={effect.id} className="absolute rounded-full animate-halo" style={{ left: `${effect.x}%`, top: `${effect.y}%`, width: '40px', height: '40px', background: 'white', boxShadow: `0 0 20px 10px white` }}/>))}
            {blessingTexts.map(blessing => (<div key={blessing.id} className="absolute text-lg font-bold text-yellow-200 animate-blessing-popup" style={{ left: `${blessing.x}%`, top: `${blessing.y}%`, textShadow: '0 0 5px rgba(0,0,0,0.7)'}}>{blessing.text}</div>))}
        </div>

        {/* --- GAME-SPECIFIC CANVASES & ELEMENTS --- */}
        {theme.gameType === 'popper' && (
            <div className="absolute inset-0 w-full h-full z-10">{bubbles.map(b => (<button key={b.id} aria-label="pop bubble" onClick={() => handleBubblePop(b)} className="absolute rounded-full transition-all duration-300 flex items-center justify-center" style={{left: `${b.x}%`, top: `${b.y}%`, width: `${b.size}px`, height: `${b.size}px`, background: `radial-gradient(circle at 65% 35%, white, ${b.color} 70%)`, opacity: b.opacity, transform: 'translate(-50%, -50%)', boxShadow: `inset -5px -5px 10px ${b.color}99, inset 5px 5px 10px white`}}>{b.type === 'heart' && <HeartIcon className="w-1/2 h-1/2 text-white/70" />}{b.type === 'splitter' && <div className="w-1/4 h-1/4 bg-white/70 rounded-full" />}</button>))}</div>
        )}
        {(theme.gameType === 'drawing' || theme.gameType === 'fluid' || theme.gameType === 'generative') && (
            <canvas ref={canvasRef} className={`absolute inset-0 z-10 w-full h-full ${theme.gameType === 'drawing' ? 'cursor-crosshair' : 'cursor-pointer'}`} onClick={handleCanvasClick} />
        )}
        {theme.gameType === 'fluid' && <div className="absolute inset-0 z-0 pointer-events-none">{riverMoons.map(m => <div key={m.id} className="absolute" style={{ left: `${m.x}%`, top: `${m.y}%`, width: `${m.size}px`, height: `${m.size}px`, transform: `translate(-50%, -50%)`, filter: 'blur(1px)' }}><svg viewBox="0 0 24 24" style={{color: m.color, opacity: m.opacity}}><path d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.64-.11 2.41-.31-3.12-.91-5.41-3.93-5.41-7.42 0-4.49 3.58-8.1 8-8.1.18 0 .35 0 .53.02-1.24-1.92-3.3-3.19-5.53-3.19z" fill="currentColor"/></svg></div>)}{ripples.map(r => <div key={r.id} className="absolute rounded-full border-2" style={{ left: `${r.x}%`, top: `${r.y}%`, width: `${r.age * 25}%`, paddingTop: `${r.age*25}%`, opacity: 1 - r.age, borderColor: r.color, transform: `translate(-50%, -50%)`}} />)}</div>}
        {theme.gameType === 'discovery' && 
            <>
                <div className="absolute inset-0 z-10 cursor-crosshair" onMouseMove={handleCloudReveal}>
                    <div className="absolute inset-0 z-0">{cloudFragments.map(f => <div key={f.id} className="absolute" style={{ left: `${f.x}%`, top: `${f.y}%`, transition: 'opacity 0.5s, transform 0.5s', opacity: discoveredFragments.has(f.id) ? 1: 0, transform: `translate(-50%, -50%) scale(${discoveredFragments.has(f.id) ? 1: 0.5})` }}><f.icon style={{filter: 'drop-shadow(0 0 10px white)'}} /></div>)}</div>
                    <canvas ref={maskCanvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />
                    {cloudParticles.map(p => <div key={p.id} className="absolute bg-white/80 rounded-full" style={{ left: p.x, top: p.y, width: p.size, height: p.size, opacity: p.opacity, transform: 'translate(-50%, -50%)' }} />)}
                </div>
                {isDiscoveryRoundOver && (
                  <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center z-20 animate-fade-in">
                    <Card className="p-6 text-center">
                      <p className="text-xl text-white mb-4">{t('cloudSeaComplete')}</p>
                      <button
                          onClick={resetCloudGame}
                          className="px-6 py-2 bg-jelly-pink rounded-full text-white font-semibold transition-transform active:scale-95"
                      >
                          {t('newRound')}
                      </button>
                    </Card>
                  </div>
                )}
            </>
        }
        {theme.gameType === 'generative' && <div className="absolute inset-0 z-0 pointer-events-none">{gardenPlants.map(p => <div key={p.id} className="absolute" style={{left:`${p.x}%`, top: `${p.y}%`, width: `${p.size}px`, height: `${p.size}px`, transform:`translate(-50%, -100%) rotate(${p.rotation}deg)`}}><svg viewBox="0 0 100 100" className="overflow-visible"><path d={p.path} stroke={`hsl(${p.creationTime % 360}, 80%, 70%)`} strokeWidth="4" fill="none" strokeLinecap="round" style={{ strokeDasharray: 150, strokeDashoffset: Math.max(0, 150 - (Date.now() - p.creationTime) / 5), transition: 'stroke-dashoffset 0.5s ease-out, opacity 1s 1s ease-in', opacity: (Date.now() - p.creationTime > 2000) ? 0 : 1, filter: 'drop-shadow(0 0 3px hsl(${p.creationTime % 360}, 80%, 70%))' }} /></svg></div>)}{isLeafShowerActive && Array.from({length: 30}).map((_, i) => <div key={i} className="absolute text-2xl" style={{left: `${Math.random()*100}%`, animation: `fall ${5+Math.random()*5}s linear ${Math.random()*2}s forwards`}}>🍃</div>)}</div>}


        {/* --- UI OVERLAY --- */}
        <div className="absolute inset-0 z-20 pointer-events-none p-4 sm:p-8 flex flex-col items-center">
            {renderCounter()}
            
            {constellationInfo && (
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-sm p-4 text-center pointer-events-auto animate-fade-in">
                    <h3 className="text-2xl font-bold text-yellow-200" style={{textShadow: '0 0 8px rgba(253, 224, 71, 0.7)'}}>{constellationInfo.name}</h3>
                    <p className="text-white/80 mt-2">{constellationInfo.description}</p>
                </div>
            )}
            {isNaming && (
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-white/80 animate-pulse">{t('generatingReport')}</div>
            )}
            
            <div className="absolute bottom-0 left-0 right-0 pointer-events-auto flex flex-col items-center gap-4" style={{ paddingBottom: 'calc(1.5rem + env(safe-area-inset-bottom))' }}>
                {(theme.gameType === 'count-generator' || theme.gameType === 'tap-generator' || theme.gameType === 'blow-generator') && (
                    <div
                        aria-label={`Interact with ${t(theme.id as TranslationKey)}`}
                        className="w-36 h-36 sm:w-40 sm:h-40 flex items-center justify-center cursor-pointer"
                        onClick={handleInteraction}
                        onTouchStart={(e) => { e.preventDefault(); handleInteraction(); }}
                    >
                        {theme.gameType === 'tap-generator' ? (
                            <div className="relative w-36 h-36 sm:w-40 sm:h-40 flex items-center justify-center">
                                <activeItem.icon className="w-32 h-32 sm:w-36 sm:h-36" />
                                <WoodenMalletIcon className={`w-20 h-20 sm:w-24 sm:h-24 absolute -top-6 -right-3 sm:-top-8 sm:-right-4 transition-transform duration-300 origin-bottom-left ${isMalletAnimating ? 'animate-mallet-strike' : ' -rotate-10'}`} />
                                {soundWaves.map(wave => (
                                    <div key={wave.id} className="absolute inset-0 rounded-full border-2 border-amber-200/50 animate-sound-wave" />
                                ))}
                            </div>
                        ) : (
                            <div className={`w-28 h-28 sm:w-32 sm:h-32 ${activeItem.bgColor} rounded-full flex items-center justify-center shadow-lg transition-transform duration-300 active:scale-95`}>
                            <activeItem.icon className={`${activeItem.color} w-16 h-16 sm:w-20 sm:h-20`} />
                            </div>
                        )}
                    </div>
                )}

                <button
                    onClick={handleEndSession}
                    className="px-8 py-2 bg-black/20 hover:bg-black/30 backdrop-blur-sm border border-white/20 rounded-full transition-all duration-300 text-lg font-semibold shadow-lg active:scale-95"
                >
                    {t('end')}
                </button>
            </div>
        </div>
    </div>
  );
};

export default GameScreen;