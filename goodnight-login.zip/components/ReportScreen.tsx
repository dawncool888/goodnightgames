import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import Card from './common/Card';
import { SHOP_ITEMS, useTranslations, PAGE_TURN_AUDIO } from '../constants';
import { generateFunReport } from '../services/geminiService';
import type { GameState, Settings, GameTheme, TranslationKey } from '../types';
import { ChevronLeftIcon, ChevronRightIcon, LogbookIcon } from './icons/ThemeIcons';

// Helper to format duration from seconds to MM:SS
const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
};

// Helper to get today's date string in YYYY-MM-DD format
const getTodayDateString = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

const Statistics: React.FC<{ history: GameState[], settings: Settings }> = ({ history, settings }) => {
    const t = useTranslations(settings.language);

    const { durationData, preferencesData } = useMemo(() => {
        // --- Duration Data (Last 30 days) ---
        const dailyDurations: { [date: string]: number } = {};
        history.forEach(session => {
            dailyDurations[session.date] = (dailyDurations[session.date] || 0) + session.duration;
        });

        const durationPoints = [];
        for (let i = 29; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            const dateStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
            durationPoints.push({
                date: dateStr,
                duration: dailyDurations[dateStr] || 0,
            });
        }
        
        // --- Preferences Data ---
        const sessionCounts: { [themeId: string]: number } = {};
        history.forEach(session => {
            sessionCounts[session.themeId] = (sessionCounts[session.themeId] || 0) + 1;
        });

        const prefs = Object.entries(sessionCounts)
            .map(([themeId, count]) => {
                const theme = SHOP_ITEMS.find(t => t.id === themeId);
                return { theme, count };
            })
            .filter(item => item.theme && item.theme.category === 'game')
            .sort((a, b) => b.count - a.count);

        return { durationData: durationPoints, preferencesData: prefs as {theme: GameTheme, count: number}[] };

    }, [history]);

    if (history.length === 0) {
        return (
            <>
                <Card className="p-4 w-full">
                    <h3 className="font-bold text-lg mb-2 text-center">{t('dailyDuration')}</h3>
                    <div className="h-48 flex items-center justify-center">
                        <p className="text-white/80 text-center">{t('noDataPrompt')}</p>
                    </div>
                </Card>
                <Card className="p-4 w-full">
                    <h3 className="font-bold text-lg mb-2 text-center">{t('favoriteGames')}</h3>
                    <div className="h-32 flex items-center justify-center">
                        <p className="text-white/80 text-center">{t('noDataPrompt')}</p>
                    </div>
                </Card>
            </>
        );
    }

    const maxDuration = Math.max(...durationData.map(d => d.duration), 1); // Avoid division by zero

    return (
        <>
            <Card className="p-4 w-full">
                <h3 className="font-bold text-lg mb-2 text-center">{t('dailyDuration')}</h3>
                <div className="w-full h-48">
                    <svg width="100%" height="100%" viewBox="0 0 300 100" preserveAspectRatio="none">
                        <path 
                            d={durationData.map((p, i) => {
                                const x = (i / 29) * 300;
                                const y = 100 - (p.duration / maxDuration) * 90; // 90 to leave margin
                                return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                            }).join(' ')}
                            fill="none"
                            stroke="var(--jelly-pink)"
                            strokeWidth="2"
                        />
                         <path 
                            d={durationData.map((p, i) => {
                                const x = (i / 29) * 300;
                                const y = 100 - (p.duration / maxDuration) * 90;
                                return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                            }).join(' ') + ' L 300 100 L 0 100 Z'}
                            fill="url(#duration-gradient)"
                        />
                        <defs>
                            <linearGradient id="duration-gradient" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor="var(--jelly-pink)" stopOpacity="0.3"/>
                                <stop offset="100%" stopColor="var(--jelly-pink)" stopOpacity="0"/>
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
            </Card>
             <Card className="p-4 w-full">
                <h3 className="font-bold text-lg mb-4 text-center">{t('favoriteGames')}</h3>
                <div className="space-y-3">
                    {preferencesData.map(({ theme, count }) => (
                        <div key={theme.id} className="flex items-center gap-3">
                            <theme.icon className="w-6 h-6 flex-shrink-0" />
                            <div className="flex-grow bg-white/10 rounded-full h-4">
                               <div 
                                 className="h-4 rounded-full"
                                 style={{ 
                                     width: `${(count / preferencesData[0].count) * 100}%`,
                                     background: `linear-gradient(to right, ${theme.gradientFrom}, ${theme.gradientTo})`
                                 }}
                               />
                            </div>
                            <span className="text-sm text-white/80 w-20 text-right">
                                {count} {count === 1 ? t('sessionUnitOne') : t('sessionsUnitPlural')}
                            </span>
                        </div>
                    ))}
                </div>
            </Card>
        </>
    )
}

interface ReportScreenProps {
  history: GameState[];
  settings: Settings;
  dailyReportCount: number;
  onNavigateToLogbook: () => void;
}

const ReportScreen: React.FC<ReportScreenProps> = ({ history, settings, onNavigateToLogbook }) => {
    const t = useTranslations(settings.language);
    const [viewDate, setViewDate] = useState(new Date());
    const [selectedDate, setSelectedDate] = useState<string | null>(null);
    const [reportText, setReportText] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    
    const audioRef = useRef<HTMLAudioElement | null>(null);

    const reportsByDate = useMemo(() => {
        const grouped: Record<string, GameState[]> = history.reduce((acc, session) => {
            (acc[session.date] = acc[session.date] || []).push(session);
            return acc;
        }, {} as Record<string, GameState[]>);
        return Object.entries(grouped)
            .map(([date, sessions]) => ({ date, sessions }))
            .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    }, [history]);

    const datesWithEntries = useMemo(() => new Set(reportsByDate.map(r => r.date)), [reportsByDate]);
    
    useEffect(() => {
        if (reportsByDate.length > 0 && !selectedDate) {
            const latestDate = reportsByDate[reportsByDate.length - 1].date;
            setSelectedDate(latestDate);
            setViewDate(new Date(latestDate + 'T00:00:00'));
        } else if (reportsByDate.length === 0) {
            setSelectedDate(null);
            setViewDate(new Date());
        }
    }, [reportsByDate, selectedDate]);
    
    const playSound = useCallback(() => {
        if (settings.sfx && audioRef.current) {
            audioRef.current.currentTime = 0;
            audioRef.current.play().catch(e => console.error("Audio play failed:", e));
        }
    }, [settings.sfx]);

    useEffect(() => {
        if (PAGE_TURN_AUDIO) {
            audioRef.current = new Audio(PAGE_TURN_AUDIO);
            audioRef.current.volume = 0.5;
        }
    }, []);

    const selectedDayData = useMemo(() => {
        if (!selectedDate) return null;
        return reportsByDate.find(r => r.date === selectedDate);
    }, [selectedDate, reportsByDate]);

    useEffect(() => {
        if (!selectedDayData) {
            setReportText('');
            setIsLoading(false);
            return;
        }

        const latestSessionToday = selectedDayData.sessions[selectedDayData.sessions.length - 1];
        const theme = SHOP_ITEMS.find(t => t.id === latestSessionToday.themeId) as GameTheme | undefined;
        
        if (!theme) {
            setReportText(t('reportError'));
            setIsLoading(false);
            return;
        }
        
        const isLatestDayWithData = reportsByDate.length > 0 && selectedDayData.date === reportsByDate[reportsByDate.length - 1].date;

        if (isLatestDayWithData) {
            setIsLoading(true);
            setReportText('');
            generateFunReport(
                { theme, clicks: latestSessionToday.clicks, duration: latestSessionToday.duration },
                settings.language
            ).then(text => {
                setReportText(text);
            }).catch(() => {
                setReportText(t('reportError'));
            }).finally(() => {
                setIsLoading(false);
            });
        } else {
            setIsLoading(false);
            const pastReportMessage = settings.language === 'zh'
                ? `在 ${selectedDayData.date}，你度过了一段宁静的时光。`
                : `On ${selectedDayData.date}, you spent some peaceful moments.`
            setReportText(pastReportMessage);
        }

    }, [selectedDayData, settings.language, t, reportsByDate]);

    const handleDayChange = useCallback((direction: -1 | 1) => {
        playSound();
        if (!selectedDate) return;
        
        const currentIndex = reportsByDate.findIndex(r => r.date === selectedDate);
        if (currentIndex === -1) return;

        const newIndex = currentIndex + direction;

        if (newIndex >= 0 && newIndex < reportsByDate.length) {
            const newDate = reportsByDate[newIndex].date;
            setSelectedDate(newDate);
            setViewDate(new Date(newDate + 'T00:00:00'));
        }
    }, [playSound, selectedDate, reportsByDate]);
    
    const renderCalendar = () => {
        const year = viewDate.getFullYear();
        const month = viewDate.getMonth();
        const monthName = viewDate.toLocaleDateString(settings.language === 'zh' ? 'zh-CN' : 'en-US', { year: 'numeric', month: 'long' });
        
        const firstDayOfMonth = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const todayString = getTodayDateString();

        const calendarDays = [];
        for (let i = 0; i < firstDayOfMonth; i++) {
            calendarDays.push(<div key={`empty-start-${i}`} className="p-1" />);
        }
        for (let day = 1; day <= daysInMonth; day++) {
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const isSelected = dateStr === selectedDate;
            const hasEntry = datesWithEntries.has(dateStr);
            const isToday = dateStr === todayString;

            calendarDays.push(
                <div key={day} className="flex justify-center items-center">
                    <button
                        onClick={() => {
                            if(hasEntry) setSelectedDate(dateStr)
                        }}
                        disabled={!hasEntry}
                        className={`relative w-9 h-9 flex items-center justify-center rounded-full transition-colors duration-200 
                            ${isSelected ? 'bg-jelly-pink text-white' : ''}
                            ${!isSelected && hasEntry ? 'hover:bg-white/20' : ''}
                            ${!isSelected && isToday ? 'border border-white/50' : ''}
                            ${!hasEntry ? 'text-white/40 cursor-default' : 'text-white'}`}
                    >
                        {day}
                        {hasEntry && !isSelected && <div className="absolute bottom-1 w-1.5 h-1.5 bg-jelly-pink rounded-full" />}
                    </button>
                </div>
            );
        }

        return (
            <Card className="p-4 w-full">
                <div className="flex items-center justify-between mb-2">
                    <button onClick={() => setViewDate(d => new Date(d.getFullYear(), d.getMonth() - 1, 1))} className="p-2 rounded-full hover:bg-white/20">
                        <ChevronLeftIcon className="w-5 h-5" />
                    </button>
                    <h3 className="font-bold text-lg">{monthName}</h3>
                    <button onClick={() => setViewDate(d => new Date(d.getFullYear(), d.getMonth() + 1, 1))} className="p-2 rounded-full hover:bg-white/20">
                        <ChevronRightIcon className="w-5 h-5" />
                    </button>
                </div>
                <div className="grid grid-cols-7 gap-y-1 text-center text-xs text-white/60 mb-2">
                    { (settings.language === 'en' ? ['S', 'M', 'T', 'W', 'T', 'F', 'S'] : ['日', '一', '二', '三', '四', '五', '六']).map(d => <div key={d} className="w-full text-center">{d}</div>) }
                </div>
                <div className="grid grid-cols-7 gap-y-2">
                    {calendarDays}
                </div>
            </Card>
        );
    }
    
    const renderDiaryCard = () => {
        if (!selectedDayData || history.length === 0) {
             return (
                <Card className="p-6 h-64 flex items-center justify-center">
                    <p className="text-white/80 text-center">{t('noDataPrompt')}</p>
                </Card>
            );
        }

        const { sessions, date } = selectedDayData;
        const totalClicksToday = sessions.reduce((sum, s) => sum + s.clicks, 0);
        const totalDurationToday = sessions.reduce((sum, s) => sum + s.duration, 0);
        const uniqueThemes = [...new Set(sessions.map(s => s.themeId))].map(id => SHOP_ITEMS.find(t => t.id === id)).filter(Boolean);
        const wishFulfilledSession = sessions.find(s => s.isWishFulfilled);

        return (
            <Card>
                <div className="flex p-4">
                    <div className="w-1/3 pr-3 border-r border-white/20 flex flex-col items-center text-center">
                        <div className="flex -space-x-4 mb-3">
                            {uniqueThemes.map((theme, i) => (
                                <div key={i} className={`w-8 h-8 rounded-full flex items-center justify-center ${theme.bgColor} border-2 border-night-sky-end`}>
                                    <theme.icon className="w-5 h-5" />
                                </div>
                            ))}
                        </div>
                        <p className="text-2xl font-bold">{totalClicksToday}</p>
                        <p className="text-xs text-white/70 mb-2">{t('interactionCount')}</p>
                        <p className="text-2xl font-bold">{formatDuration(totalDurationToday)}</p>
                        <p className="text-xs text-white/70">{t('durationBeforeSleep')}</p>
                        
                        {wishFulfilledSession && (
                             <div className="mt-3 text-xs bg-yellow-400/10 text-yellow-200 rounded-lg p-2 text-center w-full">
                                {/* FIX: Removed `|| ''` which caused a type error. */}
                                <p className="font-bold">✨ {t('wishFulfilled', { themeName: t(wishFulfilledSession.themeId as TranslationKey) })} ✨</p>
                                <p className="mt-1 italic">{t('wishFulfilledQuote')}</p>
                            </div>
                        )}
                    </div>
                    <div className="w-2/3 pl-4 flex flex-col">
                        <h4 className="font-bold text-lg text-white/90">
                            {new Date(date + 'T00:00:00').toLocaleDateString(settings.language === 'zh' ? 'zh-CN' : 'en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                        </h4>
                        <div className="flex-grow my-2 min-h-[8rem]">
                             {isLoading ? (
                                <p className="text-center text-white/80 animate-pulse">{t('generatingReport')}</p>
                            ) : (
                                <p className="text-white/80 whitespace-pre-wrap leading-relaxed text-sm">{reportText}</p>
                            )}
                        </div>
                         <p className="text-xs text-jelly-pink text-right">{t('reportLimitMessage', { count: sessions.length })}</p>
                    </div>
                </div>
                <div className="border-t border-white/20 p-2 flex justify-between">
                     <button onClick={() => handleDayChange(-1)} disabled={reportsByDate.findIndex(r => r.date === selectedDate) === 0} className="flex items-center gap-1 text-sm text-white/80 disabled:opacity-30 hover:text-white transition-transform active:scale-95">
                        <ChevronLeftIcon className="w-4 h-4" /> {t('prevDay')}
                    </button>
                    <button onClick={() => handleDayChange(1)} disabled={reportsByDate.findIndex(r => r.date === selectedDate) === reportsByDate.length - 1} className="flex items-center gap-1 text-sm text-white/80 disabled:opacity-30 hover:text-white transition-transform active:scale-95">
                        {t('nextDay')} <ChevronRightIcon className="w-4 h-4" />
                    </button>
                </div>
            </Card>
        )
    }

    return (
        <div className="flex flex-col items-center w-full h-full max-w-md mx-auto">
            <h1 className="text-3xl font-bold text-white mb-4 flex-shrink-0">{t('diaryTitle')}</h1>
             <button 
                onClick={onNavigateToLogbook}
                className="w-full mb-4 text-center p-3 rounded-full border border-white/50 bg-white/5 hover:bg-white/10 transition-all duration-300 flex items-center justify-center gap-2"
            >
                <LogbookIcon className="w-5 h-5 text-white/90"/>
                <span className="font-semibold text-white/90">{t('viewMyStarrySkyDiary')}</span>
            </button>
            
            <div className="w-full flex-grow overflow-y-auto space-y-4 pr-1 pb-4">
                {renderCalendar()}
                {renderDiaryCard()}
                <Statistics history={history} settings={settings} />
            </div>
        </div>
    );
};

export default ReportScreen;